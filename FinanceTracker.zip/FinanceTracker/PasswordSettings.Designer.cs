﻿namespace Project
{
    partial class PasswordSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_current_password = new Label();
            lb_new_password = new Label();
            lb_confirm_password = new Label();
            tb_current_password = new TextBox();
            tb_new_password = new TextBox();
            tb_confirm_password = new TextBox();
            bt_update = new Button();
            SuspendLayout();
            // 
            // lb_current_password
            // 
            lb_current_password.AutoSize = true;
            lb_current_password.Location = new Point(51, 25);
            lb_current_password.Name = "lb_current_password";
            lb_current_password.Size = new Size(67, 15);
            lb_current_password.TabIndex = 0;
            lb_current_password.Text = "Current Pin";
            // 
            // lb_new_password
            // 
            lb_new_password.AutoSize = true;
            lb_new_password.Location = new Point(51, 66);
            lb_new_password.Name = "lb_new_password";
            lb_new_password.Size = new Size(51, 15);
            lb_new_password.TabIndex = 1;
            lb_new_password.Text = "New Pin";
            
            // 
            // lb_confirm_password
            // 
            lb_confirm_password.AutoSize = true;
            lb_confirm_password.Location = new Point(51, 107);
            lb_confirm_password.Name = "lb_confirm_password";
            lb_confirm_password.Size = new Size(71, 15);
            lb_confirm_password.TabIndex = 2;
            lb_confirm_password.Text = "Confirm Pin";
            // 
            // tb_current_password
            // 
            tb_current_password.Location = new Point(137, 17);
            tb_current_password.Name = "tb_current_password";
            tb_current_password.Size = new Size(100, 23);
            tb_current_password.TabIndex = 3;
            tb_current_password.PasswordChar = '*';
            // 
            // tb_new_password
            // 
            tb_new_password.Location = new Point(137, 58);
            tb_new_password.Name = "tb_new_password";
            tb_new_password.Size = new Size(100, 23);
            tb_new_password.TabIndex = 4;
            tb_new_password.PasswordChar = '*';
            // 
            // tb_confirm_password
            // 
            tb_confirm_password.Location = new Point(137, 99);
            tb_confirm_password.Name = "tb_confirm_password";
            tb_confirm_password.Size = new Size(100, 23);
            tb_confirm_password.TabIndex = 5;
            tb_confirm_password.PasswordChar = '*';
            // 
            // bt_update
            // 
            bt_update.Location = new Point(111, 145);
            bt_update.Name = "bt_update";
            bt_update.Size = new Size(75, 23);
            bt_update.TabIndex = 6;
            bt_update.Text = "Update";
            bt_update.UseVisualStyleBackColor = true;
            bt_update.Click += UpdatePassword;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(308, 180);
            Controls.Add(bt_update);
            Controls.Add(tb_confirm_password);
            Controls.Add(tb_new_password);
            Controls.Add(tb_current_password);
            Controls.Add(lb_confirm_password);
            Controls.Add(lb_new_password);
            Controls.Add(lb_current_password);
            Name = "Form2";
            Text = "Change Pin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lb_current_password;
        private Label lb_new_password;
        private Label lb_confirm_password;
        private TextBox tb_current_password;
        private TextBox tb_new_password;
        private TextBox tb_confirm_password;
        private Button bt_update;
    }
}