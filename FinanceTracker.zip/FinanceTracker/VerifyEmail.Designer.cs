namespace login_windos;

    partial class email_chek
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtemail = new TextBox();
            lblemail = new Label();
            label3 = new Label();
            labverification = new Label();
            btnsubmit = new Button();
            SuspendLayout();
            // 
            // txtemail
            // 
            txtemail.Location = new Point(255, 105);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(248, 27);
            txtemail.TabIndex = 0;
            txtemail.TextChanged+=email_chek_onchanged;
            // 
            // lblemail
            // 
            lblemail.AutoSize = true;
            lblemail.Location = new Point(178, 112);
            lblemail.Name = "lblemail";
            lblemail.Size = new Size(46, 20);
            lblemail.TabIndex = 2;
            lblemail.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 135);
            label3.Name = "label3";
            label3.Size = new Size(21, 20);
            label3.TabIndex = 4;
            label3.Text = "--";
            // 
            // labverification
            // 
            labverification.Font = new Font("Segoe UI", 15F);
            labverification.Location = new Point(302, 44);
            labverification.Name = "labverification";
            labverification.Size = new Size(178, 43);
            labverification.TabIndex = 6;
            labverification.Text = "Verify Email";
            // 
            // btnsubmit
            // 
            btnsubmit.Location = new Point(255, 158);
            btnsubmit.Name = "btnsubmit";
            btnsubmit.Size = new Size(248, 42);
            btnsubmit.TabIndex = 7;
            btnsubmit.Text = "Submit";
            btnsubmit.UseVisualStyleBackColor = true;
            btnsubmit.Click+=submit_click;
            // 
            // email_chek
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnsubmit);
            Controls.Add(labverification);
            Controls.Add(label3);
            Controls.Add(lblemail);
            Controls.Add(txtemail);
            Name = "email_chek";
            Text = "email_chek";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtemail;
        private TextBox txtpassword;
        private Label lblemail;
        private Label lblpassword;
        private Label label3;
        private Label label4;
        private Label labverification;
        private Button btnsubmit;
        private LinkLabel linkLabel1;
    }
