﻿namespace login_windos
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reports));
            lblTitle = new Label();
            btnExport = new Button();
            budgetGridView = new DataGridView();
            label1 = new Label();
            btnPieChart = new Button();
            button1 = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)budgetGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(237, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(78, 25);
            lblTitle.TabIndex = 1;
            lblTitle.Text = "Reports";
            // 
            // btnExport
            // 
            btnExport.Location = new Point(228, 415);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(87, 23);
            btnExport.TabIndex = 2;
            btnExport.Text = "Export Report";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // budgetGridView
            // 
            budgetGridView.BorderStyle = BorderStyle.Fixed3D;
            budgetGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            budgetGridView.Location = new Point(35, 37);
            budgetGridView.Name = "budgetGridView";
            budgetGridView.Size = new Size(488, 372);
            budgetGridView.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(632, 12);
            label1.Name = "label1";
            label1.Size = new Size(68, 25);
            label1.TabIndex = 5;
            label1.Text = "Charts";
            // 
            // btnPieChart
            // 
            btnPieChart.BackgroundImage = (Image)resources.GetObject("btnPieChart.BackgroundImage");
            btnPieChart.Location = new Point(607, 138);
            btnPieChart.Name = "btnPieChart";
            btnPieChart.Size = new Size(114, 23);
            btnPieChart.TabIndex = 6;
            btnPieChart.Text = "Expense Pie Chart";
            btnPieChart.UseVisualStyleBackColor = true;
            btnPieChart.Click += btnPieChart_Click;
            // 
            // button1
            // 
            button1.Location = new Point(610, 272);
            button1.Name = "button1";
            button1.Size = new Size(114, 23);
            button1.TabIndex = 8;
            button1.Text = "Time Line Chart";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(591, 408);
            button2.Name = "button2";
            button2.Size = new Size(148, 23);
            button2.TabIndex = 9;
            button2.Text = "Expense Bar Chart";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(608, 47);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(113, 87);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BorderStyle = BorderStyle.Fixed3D;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(608, 179);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(113, 87);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BorderStyle = BorderStyle.Fixed3D;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(611, 315);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(113, 87);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // Reports
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btnPieChart);
            Controls.Add(label1);
            Controls.Add(budgetGridView);
            Controls.Add(btnExport);
            Controls.Add(lblTitle);
            Name = "Reports";
            Text = "Reports";
            ((System.ComponentModel.ISupportInitialize)budgetGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblTitle;
        private Button btnExport;
        private DataGridView budgetGridView;
        private Label label1;
        private Button btnPieChart;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}