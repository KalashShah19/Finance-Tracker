﻿namespace Project;

partial class ProfileSettings
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        pb_image = new PictureBox();
        lb_name = new Label();
        lb_contact = new Label();
        lb_email = new Label();
        tb_contact = new TextBox();
        bt_update = new Button();
        lb_dob = new Label();
        lb_showname = new Label();
        lb_showdob = new Label();
        cb_darkmode = new CheckBox();
        lb_theme = new Label();
        lb_showemail = new Label();
        ((System.ComponentModel.ISupportInitialize)pb_image).BeginInit();
        SuspendLayout();
        // 
        // pb_image
        // 
        pb_image.BorderStyle = BorderStyle.FixedSingle;
        pb_image.Location = new Point(61, 86);
        pb_image.Name = "pb_image";
        pb_image.Size = new Size(178, 256);
        pb_image.SizeMode = PictureBoxSizeMode.StretchImage;
        pb_image.TabIndex = 0;
        pb_image.TabStop = false;
        pb_image.Click += PickImageHelper;
        // 
        // lb_name
        // 
        lb_name.AutoSize = true;
        lb_name.Location = new Point(61, 51);
        lb_name.Name = "lb_name";
        lb_name.Size = new Size(39, 15);
        lb_name.TabIndex = 1;
        lb_name.Text = "Name";
        // 
        // lb_contact
        // 
        lb_contact.AutoSize = true;
        lb_contact.Location = new Point(337, 153);
        lb_contact.Name = "lb_contact";
        lb_contact.Size = new Size(49, 15);
        lb_contact.TabIndex = 2;
        lb_contact.Text = "Contact";
        // 
        // lb_email
        // 
        lb_email.AutoSize = true;
        lb_email.Location = new Point(337, 108);
        lb_email.Name = "lb_email";
        lb_email.Size = new Size(36, 15);
        lb_email.TabIndex = 3;
        lb_email.Text = "Email";
        // 
        // tb_contact
        // 
        tb_contact.Location = new Point(434, 150);
        tb_contact.Name = "tb_contact";
        tb_contact.Size = new Size(124, 23);
        tb_contact.TabIndex = 7;
        // 
        // bt_update
        // 
        bt_update.Location = new Point(397, 301);
        bt_update.Name = "bt_update";
        bt_update.Size = new Size(75, 23);
        bt_update.TabIndex = 10;
        bt_update.Text = "Update";
        bt_update.UseVisualStyleBackColor = true;
        bt_update.Click += UpdateUserData;
        // 
        // lb_dob
        // 
        lb_dob.AutoSize = true;
        lb_dob.Location = new Point(337, 204);
        lb_dob.Name = "lb_dob";
        lb_dob.Size = new Size(73, 15);
        lb_dob.TabIndex = 11;
        lb_dob.Text = "Date of Birth";
        // 
        // lb_showname
        // 
        lb_showname.AutoSize = true;
        lb_showname.Location = new Point(159, 51);
        lb_showname.Name = "lb_showname";
        lb_showname.Size = new Size(80, 15);
        lb_showname.TabIndex = 13;
        lb_showname.Text = "lb_showname";
        // 
        // lb_showdob
        // 
        lb_showdob.AutoSize = true;
        lb_showdob.Location = new Point(434, 204);
        lb_showdob.Name = "lb_showdob";
        lb_showdob.Size = new Size(71, 15);
        lb_showdob.TabIndex = 14;
        lb_showdob.Text = "lb_showdob";
        // 
        // cb_darkmode
        // 
        cb_darkmode.AutoSize = true;
        cb_darkmode.Location = new Point(434, 243);
        cb_darkmode.Name = "cb_darkmode";
        cb_darkmode.Size = new Size(87, 19);
        cb_darkmode.TabIndex = 15;
        cb_darkmode.Text = "Dark theme";
        cb_darkmode.UseVisualStyleBackColor = true;
        // 
        // lb_theme
        // 
        lb_theme.AutoSize = true;
        lb_theme.Location = new Point(337, 244);
        lb_theme.Name = "lb_theme";
        lb_theme.Size = new Size(43, 15);
        lb_theme.TabIndex = 16;
        lb_theme.Text = "Theme";
        // 
        // lb_showemail
        // 
        lb_showemail.AutoSize = true;
        lb_showemail.Location = new Point(434, 108);
        lb_showemail.Name = "lb_showemail";
        lb_showemail.Size = new Size(79, 15);
        lb_showemail.TabIndex = 17;
        lb_showemail.Text = "lb_showemail";
        // 
        // ProfileSettings
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(644, 377);
        Controls.Add(lb_showemail);
        Controls.Add(lb_theme);
        Controls.Add(cb_darkmode);
        Controls.Add(lb_showdob);
        Controls.Add(lb_showname);
        Controls.Add(lb_dob);
        Controls.Add(bt_update);
        Controls.Add(tb_contact);
        Controls.Add(lb_email);
        Controls.Add(lb_contact);
        Controls.Add(lb_name);
        Controls.Add(pb_image);
        Name = "ProfileSettings";
        Text = "Settings";
        ((System.ComponentModel.ISupportInitialize)pb_image).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private PictureBox pb_image;
    private Label lb_name;
    private Label lb_contact;
    private Label lb_email;
    private TextBox tb_contact;
    private Button bt_update;
    private Label lb_dob;
    private Label lb_showname;
    private Label lb_showdob;
    private CheckBox cb_darkmode;
    private Label lb_theme;
    private Label lb_showemail;
}
