﻿using MindFusion.Charting;
using MindFusion.Drawing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SolidBrush = MindFusion.Drawing.SolidBrush;
using MindFusion.Charting.WinForms;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Drawing.Imaging;

namespace login_windos
{


    public partial class PieChart : Form
    {
        public PieChart()
        {
            InitializeComponent();
            LoadMonthlyExpensesAndConfigurePieChart();
        }

        private void LoadMonthlyExpensesAndConfigurePieChart()
        {
            var (amounts, monthYears) = GetMonthlyExpensesFromDatabase();

            PieChartExpense.Dock = DockStyle.Fill;
            PieChartExpense.ShowLegend = true;
            PieChartExpense.LegendTitle = "Monthly Expenses Statistics";
            PieChartExpense.StartAngle = 0;

            PieChartExpense.Series = new CustomPieSeries(amounts, monthYears);

            PieChartExpense.Plot.SeriesStyle = new PerElementSeriesStyle()
            {
                Fills = new List<List<MindFusion.Drawing.Brush>>()
                {
                    new List<MindFusion.Drawing.Brush>()
                    {
                        new SolidBrush(Color.White),
                        new SolidBrush(Color.LightGreen),
                        new SolidBrush(Color.Red),
                        new SolidBrush(Color.Blue)
                    }
                }
            };
        }

        public void btnDownloadPieChart_Click(object sender, EventArgs e)
        {
            // Step 1: Capture the chart as an image (same as before)
            using (Bitmap bmp = new Bitmap(PieChartExpense.Width, PieChartExpense.Height))
            {

                PieChartExpense.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, PieChartExpense.Width, PieChartExpense.Height));

                // Step 2: Use SaveFileDialog to let the user specify where to save the PDF
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PDF Files (.pdf)|.pdf";
                saveFileDialog.Title = "Save Chart as PDF";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;

                    try
                    {
                        // Step 3: Create the PDF document
                        Document pdfDoc = new Document(PageSize.A4);
                        PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
                        pdfDoc.Open();

                        iTextSharp.text.Font boldFont = iTextSharp.text.FontFactory.GetFont("Times-Roman", 20, iTextSharp.text.Font.BOLD);

                        // Step 4: Add the chart image to the PDF
                        using (MemoryStream stream = new MemoryStream())
                        {
                            // Save the chart image to a memory stream
                            bmp.Save(stream, ImageFormat.Png);
                            iTextSharp.text.Image chartImage = iTextSharp.text.Image.GetInstance(stream.ToArray());
                            chartImage.Alignment = Element.ALIGN_CENTER;
                            chartImage.ScaleToFit(500f, 400f); // Resize the image to fit in the PDF
                            pdfDoc.Add(chartImage); // Add the image to the PDF
                        }

                        PdfPTable pdfTable = new PdfPTable(2)
                        {
                            WidthPercentage = 100 // Set table width to 100%
                        };

                        // Step 5: Add a table to the PDF (for example, chart data)
                        // PdfPTable pdfTable = new PdfPTable(2); // Create a table with 2 columns
                        pdfTable.WidthPercentage = 100;
                        Paragraph header = new Paragraph(" : Monthly Expenses Report : ", boldFont)
                        {
                            Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 22),
                            SpacingBefore = 15f,
                            SpacingAfter = 5f,
                            Alignment = Element.ALIGN_CENTER

                        };

                        pdfDoc.Add(header);




                        pdfTable.SpacingBefore = 30f;
                        var headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 13);
                        headerFont.Color = BaseColor.BLUE;
                        PdfPCell cell = new PdfPCell(new Phrase("Custom Color Cell", headerFont));
                        // cell.BackgroundColor = new BaseColor(0, 0, 0);


                        iTextSharp.text.Font tableHeaderFont = iTextSharp.text.FontFactory.GetFont("Helvetica", 13, iTextSharp.text.Font.BOLD);
                        tableHeaderFont.Color = BaseColor.BLUE;
                        PdfPCell monthHeaderCell = new PdfPCell(new Phrase("Month", tableHeaderFont))
                        {
                            BackgroundColor = new BaseColor(0, 0, 0),
                            HorizontalAlignment = Element.ALIGN_CENTER,
                            Padding = 05,

                        };
                        PdfPCell expensesHeaderCell = new PdfPCell(new Phrase("Expenses", tableHeaderFont))
                        {
                            BackgroundColor = new BaseColor(0, 0, 0),
                            HorizontalAlignment = Element.ALIGN_CENTER,
                            Padding = 05
                        };
                        monthHeaderCell.Phrase.Font.Color = BaseColor.WHITE;

                        // Add the header cells to the table
                        pdfTable.AddCell(monthHeaderCell);
                        pdfTable.AddCell(expensesHeaderCell);


                        // pdfTable.AddCell(new PdfPCell(new Phrase("Month", headerFont)) { BackgroundColor = new BaseColor(0, 0, 0),  HorizontalAlignment = Element.ALIGN_CENTER,  Padding = 05  });
                        // pdfTable.AddCell(new PdfPCell(new Phrase("Expenses", headerFont)) {BackgroundColor = new BaseColor(0, 0, 0),  HorizontalAlignment = Element.ALIGN_CENTER,  Padding = 05 });
                        // pdfTable.AddCell(new PdfPCell(new Phrase("Expenses", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });

                        // Add table headers
                        // pdfTable.AddCell("Month");
                        // pdfTable.AddCell("Expenses");

                        // Assuming you have your data in amounts and monthYears lists
                        var (amounts, monthYears) = GetMonthlyExpensesFromDatabase();

                        // Add table rows with data
                        for (int i = 0; i < amounts.Count; i++)
                        {
                            PdfPCell monthCell = new PdfPCell(new Phrase(monthYears[i]))
                            {
                                HorizontalAlignment = Element.ALIGN_CENTER,
                                Padding = 5
                            };


                            PdfPCell amountCell = new PdfPCell(new Phrase(amounts[i].ToString("F2")))
                            {
                                HorizontalAlignment = Element.ALIGN_CENTER, // Center the text
                                Padding = 5
                            };
                            pdfTable.AddCell(monthCell);
                            pdfTable.AddCell(amountCell);
                            // pdfTable.AddCell(monthYears[i]);
                            // pdfTable.AddCell(amounts[i].ToString("F2")); // Format to 2 decimal places
                        }

                        // Add the table to the PDF
                        pdfDoc.Add(pdfTable);

                        // Step 6: Close the PDF document
                        pdfDoc.Close();

                        MessageBox.Show("PDF downloaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving the PDF: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }


        private (List<double> amounts, List<string> monthYears) GetMonthlyExpensesFromDatabase()
        {

            string connectionString = Config.ConnectionString;


            List<double> amounts = new List<double>();
            List<string> monthYears = new List<string>();

            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(connectionString))
                {
                    con.Open();

                    string query = "SELECT TO_CHAR(c_timestamp, 'Month') AS Month, SUM(c_amount) AS TotalAmount FROM t_transactions GROUP BY TO_CHAR(c_timestamp, 'Month') ORDER BY Month;";

                    using (NpgsqlCommand command = new NpgsqlCommand(query, con))
                    {
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                monthYears.Add(reader["Month"].ToString()!);
                                amounts.Add(Convert.ToDouble(reader["TotalAmount"]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving data: " + ex.Message);
            }

            return (amounts, monthYears);
        }


        public class CustomPieSeries : Series
        {
            public CustomPieSeries(IList<double> data, IList<string> legendLabels)
            {
                values = data;
                _legendLabels = legendLabels;
                total = 0.0;
                for (int i = 0; i < data.Count; i++)
                    total += data[i];
            }

            public double GetValue(int index, int dimension)
            {
                return values[index];

            }

            public string GetLabel(int index, LabelKinds kind)
            {
                double percent = (values[index] / total) * 100;
                if (kind == LabelKinds.InnerLabel)
                    return percent.ToString("F2") + "%\n" + values[index].ToString();
                if (kind == LabelKinds.ToolTip)
                    return _legendLabels[index].ToString()!;

                if (kind == LabelKinds.ZAxisLabel)
                    return _legendLabels[index].ToString();

                return null;
            }

            public bool IsSorted(int dimension)
            {
                return false;
            }

            public bool IsEmphasized(int index)
            {
                return false;
            }

            public int Size
            {
                get { return values.Count; }
            }

            public int Dimensions
            {
                get { return 1; }
            }

            public string Title
            {
                get { return ""; }
            }

            public LabelKinds SupportedLabels
            {
                get { return LabelKinds.InnerLabel | LabelKinds.ToolTip | LabelKinds.ZAxisLabel; }
            }

            public event EventHandler DataChanged;

            IList<double> values;
            IList<string> _legendLabels;
            double total = 0L;

        }
    }
}