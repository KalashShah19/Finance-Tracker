using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Npgsql;

namespace login_windos
{


    public partial class Tracker : Form
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            return sb.ToString();
        }

        private string imagePath, imageName;
        NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);


        public Tracker()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            // Ensure all fields are filled
            if (txtfname.Text != "" && txtlname.Text != "" && txtcontact.Text != "" && txtmail.Text != "" &&
                txtpassword.Text != "" && txtcnfpassword.Text != "" && txtacc_no.Text != "" &&
                txtifsccode.Text != "" && pictureBox1.Image != null)
            {
                // Check if the passwords match
                if (txtpassword.Text != txtcnfpassword.Text)
                {
                    MessageBox.Show("Passwords do not match!");
                    return;
                }

                // Hash the password
                string password = txtpassword.Text;
                string hashedPassword = MD5Hash(password);

                // Check if Terms and Conditions checkbox is checked
                if (chktc.Checked == true)
                {
                    // Query to check if email already exists
                    string query = "SELECT c_id FROM t_customer WHERE c_email = @c_email";

                    try
                    {
                        conn.Open();

                        using (var cmd1 = new NpgsqlCommand(query, conn))
                        {
                            cmd1.Parameters.AddWithValue("@c_email", txtmail.Text);
                            var result = cmd1.ExecuteScalar();

                            // If email exists
                            if (result != null)
                            {
                                MessageBox.Show("Email already exists.");
                            }
                            else
                            {
                                // Email doesn't exist, proceed with registration
                                string save_dir = Config.imagePath + imageName;
                                pictureBox1.Image.Save(save_dir);

                                // Insert customer data and get the inserted customer ID
                                string insertCustomerQuery = @"INSERT INTO t_customer 
                            (c_fname, c_lname, c_dob, c_email, c_pin, c_contact, c_profile_image, c_dark_theme) 
                            VALUES (@fname, @lname, @dob, @mail, @pin, @contact, @path, @theme) 
                            RETURNING c_id;";

                                using (NpgsqlCommand cmd = new NpgsqlCommand(insertCustomerQuery, conn))
                                {
                                    cmd.Parameters.AddWithValue("@fname", txtfname.Text);
                                    cmd.Parameters.AddWithValue("@lname", txtlname.Text);
                                    cmd.Parameters.AddWithValue("@dob", DateTime.Parse(dtpdob.Text));
                                    cmd.Parameters.AddWithValue("@mail", txtmail.Text);
                                    cmd.Parameters.AddWithValue("@pin", hashedPassword);
                                    cmd.Parameters.AddWithValue("@contact", long.Parse(txtcontact.Text));
                                    cmd.Parameters.AddWithValue("@path", save_dir);
                                    cmd.Parameters.AddWithValue("@theme", false);

                                    var insertedId = cmd.ExecuteScalar();
                                    int customerId = Convert.ToInt32(insertedId);

                                    // Proceed with account creation if customer insertion is successful
                                    if (insertedId != null)
                                    {
                                        float balance = 15000;
                                        float monthly = 10000;

                                        string insertAccountQuery = @"INSERT INTO t_account 
                                    (c_account_num, c_id, c_balance, c_bank_name, c_ifsc_code, c_monthly_limit) 
                                    VALUES (@accountnum, @id, @balance, @bankname, @ifsc, @monthly);";

                                        using (NpgsqlCommand cmd2 = new NpgsqlCommand(insertAccountQuery, conn))
                                        {
                                            cmd2.Parameters.AddWithValue("@accountnum", long.Parse(txtacc_no.Text));
                                            cmd2.Parameters.AddWithValue("@id", customerId);
                                            cmd2.Parameters.AddWithValue("@balance", balance);
                                            cmd2.Parameters.AddWithValue("@bankname", ddbankname.Text);
                                            cmd2.Parameters.AddWithValue("@ifsc", txtifsccode.Text);
                                            cmd2.Parameters.AddWithValue("@monthly", monthly);

                                            int rowsAffected = cmd2.ExecuteNonQuery();

                                            if (rowsAffected > 0)
                                            {
                                                MessageBox.Show("Registration Successful.");
                                                this.Hide();
                                                login loginForm = new login();
                                                loginForm.Show();
                                            }
                                            else
                                            {
                                                MessageBox.Show("Failed to insert account data.");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Failed to insert customer data.");
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please check the Terms and Conditions.");
                }
            }
            else
            {
                MessageBox.Show("Please fill all the details.");
            }
        }

        //Validating Fname on textChanged
        private void txtfname_TextChanged(object sender, EventArgs e)
        {
            string input = txtfname.Text; // Replace with your input
            string pattern = @"^[a-zA-Z]+$"; // Replace with your regular expression pattern

            if (Regex.IsMatch(input, pattern))
            {
                msgfname.Text = "";
            }
            else
            {
                msgfname.Text = "First Name Must Contain Alphabets Only.";
                msgfname.ForeColor = Color.Red;
            }
        }

        // Validating Lname on textCHanged
        private void txtlname_TextChanged(object sender, EventArgs e)
        {
            string input = txtlname.Text;
            string pattern = @"^[a-zA-Z]+$";

            if (Regex.IsMatch(input, pattern))
            {
                msglname.Text = "";
            }
            else
            {
                msglname.Text = "Last Name Must Contain Alphabets Only.";
                msglname.ForeColor = Color.Red;
            }
        }

        // Validating COntact on TextChanged
        private void txtcontact_TextChanged(object sender, EventArgs e)
        {
            string input = txtcontact.Text;
            string pattern = @"^[6-9]\d{9}$";

            if (Regex.IsMatch(input, pattern))
            {
                msgphonenumber.Text = "";
            }
            else
            {
                msgphonenumber.Text = "Contact Number Must Contain 10 Digits.";
                msgphonenumber.ForeColor = Color.Red;
            }
        }


        // Validating Dob on ValueCHanged
        private void dtpdob_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = dtpdob.Value;
            DateTime today = DateTime.Today;

            int age = today.Year - selectedDate.Year;

            if (selectedDate > today.AddYears(-age))
            {
                age--;
            }


            if (age < 18)
            {
                msgdob.Text = "You Must Be Atleast 18 Years Old.";
                msgdob.ForeColor = Color.Red;
                dtpdob.Value = today.AddYears(-18);
            }
            else
            {

                msgdob.Text = "";
            }
        }

        // Validating EMail On textChanged
        private void txtmail_TextChanged(object sender, EventArgs e)
        {
            string input = txtmail.Text;
            string pattern = @"^[\w\.-]+@[a-zA-Z\d\.-]+\.[a-zA-Z]{2,6}$";

            if (Regex.IsMatch(input, pattern))
            {
                msgemail.Text = "";
            }
            else
            {
                msgemail.Text = "Email Address Format Must Be : abc@example.com";
                msgemail.ForeColor = Color.Red;
            }
        }

        // Validating Password and Confirm Password On textChanged
        // Taking Input to Paassword and Confirm Password And Verifying Both
        private void txtpassword_TextChanged(object sender, EventArgs e)
        {
            ValidatePasswords();

        }

        private void txtcnfpassword_TextChanged(object sender, EventArgs e)
        {
            ValidatePasswords();
        }

        private void ValidatePasswords()
        {
            string password = txtpassword.Text;
            string confirmPassword = txtcnfpassword.Text;


            string passwordPattern = @"^\d{4}$";

            if (!Regex.IsMatch(password, passwordPattern))
            {
                msgpassword.Text = "Password must be at 4 Digit Pin Only";
                msgpassword.ForeColor = Color.Red;
            }
            else
            {
                msgpassword.Text = "";
            }

            if (confirmPassword != password)
            {
                msgcnfpassword.Text = "Passwords do not match.";
                msgcnfpassword.ForeColor = Color.Red;
            }
            else
            {
                msgcnfpassword.Text = "";
            }


            if (Regex.IsMatch(password, passwordPattern) && confirmPassword == password)
            {
                msgcnfpassword.Text = "";
            }
        }

        // Validating Account Number On textChanged
        private void txtacc_no_TextChanged(object sender, EventArgs e)
        {
            string input = txtacc_no.Text; // Assuming txtAccountNumber is your TextBox for account number
            string pattern = @"^\d+$"; // Pattern to match digits only

            if (Regex.IsMatch(input, pattern))
            {
                msgacc_no.Text = ""; // Clear message if valid
            }
            else
            {
                msgacc_no.Text = "Account Number Must be Digits Only";
                msgacc_no.ForeColor = Color.Red; // Set error message color to red
            }
        }

        // Uploading IMage to Picture Box

        private async void btnupload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                // Correctly format the filter to include multiple image file extensions
                openFileDialog.Filter = "Image Files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All Files (*.*)|*.*";

                openFileDialog.Title = "Select a Profile Picture";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                    FileInfo fileInfo = new FileInfo(openFileDialog.FileName);
                    long fileSizeInBytes = fileInfo.Length;
                    long fileSizeInMB = fileSizeInBytes / (1024 * 1024);

                    if (fileSizeInMB > 3)
                    {
                        MessageBox.Show("Please select an image smaller than 3 MB.", "File Size Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }


                    imagePath = openFileDialog.FileName;
                    imageName = Path.GetFileName(openFileDialog.FileName);


                    progressBar1.Value = 0;
                    await SimulateUploadAsync();


                    pictureBox1.Image = Image.FromFile(imagePath);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                }
            }
        }



        private async Task SimulateUploadAsync()
        {
            // Simulate a long-running upload process
            for (int i = 0; i <= 100; i++)
            {
                await Task.Delay(50); // Simulate time delay for upload
                progressBar1.Value = i; // Update progress bar
            }

            MessageBox.Show("Upload Complete!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Validating IFSC COde on txtChanged
        private void txtifsccode_TextChanged(object sender, EventArgs e)
        {
            string input = txtifsccode.Text; // Get the input from the text box
            string pattern = @"^[A-Z]{4}[0-9]{7}$"; // Regular expression pattern for IFSC code

            if (Regex.IsMatch(input, pattern))
            {
                msgifsc.Text = ""; // Clear the message if the IFSC code is valid
            }
            else
            {
                msgifsc.Text = "Invalid IFSC Code. Format should be 4 Capital letters followed by 7 digits."; // Show error message
                msgifsc.ForeColor = Color.Red; // Set error message color to red
            }
        }

        private void Click_here(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();

        }


        private void linkterm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                // Open the URL in the default web browser
                MessageBox.Show("Terms and Conditions\n\n" +
 "1. Acceptance\n" +
 "By registering, you agree to these terms. If you disagree, do not use the service.\n\n" +
 "2. User Responsibilities\n" +
 "You must:\n" +
 "- Provide accurate information.\n" +
 "- Keep login details confidential.\n" +
 "- Use the service for personal finance tracking only.\n" +
 "- Comply with all laws.\n\n" +
 "3. Privacy and Data Use\n" +
 "We collect, store, and process your data in line with our Privacy Policy. Financial data will not be shared without consent, except as required by law.\n\n" +
 "4. Security\n" +
 "We use security measures to protect your data but cannot guarantee complete security. You must:\n" +
 "- Secure your account.\n" +
 "- Notify us of unauthorized access.\n\n" +
 "5. Account Termination\n" +
 "We may suspend or terminate your account for violating these terms or engaging in suspicious activity.\n\n" +
 "6. Disclaimer\n" +
 "The service is provided 'as is.' We do not guarantee availability, accuracy, or security.\n\n" +
 "7. Liability\n" +
 "We are not liable for indirect damages, data loss, or unauthorized access to your account.\n\n" +
 "8. Modifications\n" +
 "We may modify the service or these terms. Continued use implies acceptance of the changes.\n\n" +
 "9. Governing Law\n" +
 "These terms are governed by the laws of [Your Country/State]. Disputes are subject to the courts of [Your Country/State].\n\n" +
 "10. Contact\n" +
 "For questions, contact us at: [support@example.com].",
 "Terms and Conditions", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to open link. {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkshow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkshow.Checked == true)
            {
                txtpassword.UseSystemPasswordChar = false;

            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }

        private void chkshow2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkshow2.Checked == true)
            {
                txtcnfpassword.UseSystemPasswordChar = false;

            }
            else
            {
                txtcnfpassword.UseSystemPasswordChar = true;
            }
        }
    }
}
