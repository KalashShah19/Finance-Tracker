using login_windos;
    partial class otp_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnsubmit = new Button();
            labverification = new Label();
            label3 = new Label();
            lblotp = new Label();
            txtotp = new TextBox();
            linkLabel1 = new LinkLabel();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timer1.Tick+=timer_tick;
            SuspendLayout();
            // 
            // btnsubmit
            // 
            btnsubmit.Location = new Point(258, 170);
            btnsubmit.Name = "btnsubmit";
            btnsubmit.Size = new Size(248, 42);
            btnsubmit.TabIndex = 12;
            btnsubmit.Text = "Submit";
            btnsubmit.UseVisualStyleBackColor = true;
            btnsubmit.Click += submit_click;
            // 
            // labverification
            // 
            labverification.Font = new Font("Segoe UI", 15F);
            labverification.Location = new Point(305, 56);
            labverification.Name = "labverification";
            labverification.Size = new Size(178, 43);
            labverification.TabIndex = 11;
            labverification.Text = "Verify Otp";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(258, 147);
            label3.Name = "label3";
            label3.Size = new Size(21, 20);
            label3.TabIndex = 10;
            label3.Text = "--";
            // 
            // lblotp
            // 
            lblotp.AutoSize = true;
            lblotp.Location = new Point(206, 120);
            lblotp.Name = "lblotp";
            lblotp.Size = new Size(34, 20);
            lblotp.TabIndex = 9;
            lblotp.Text = "Otp";
            // 
            // txtotp
            // 
            txtotp.Location = new Point(258, 117);
            txtotp.Name = "txtotp";
            txtotp.Size = new Size(248, 27);
            txtotp.TabIndex = 8;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(337, 229);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(86, 20);
            linkLabel1.TabIndex = 13;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Resend Otp";
            linkLabel1.Click+=resendOtp_click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(369, 265);
            label1.Name = "label1";
            label1.Size = new Size(21, 20);
            label1.TabIndex = 14;
            label1.Text = "--";
            // 
            // otp_page
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(linkLabel1);
            Controls.Add(btnsubmit);
            Controls.Add(labverification);
            Controls.Add(label3);
            Controls.Add(lblotp);
            Controls.Add(txtotp);
            Name = "otp_page";
            Text = "otp_page";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnsubmit;
        private Label labverification;
        private Label label3;
        private Label lblotp;
        private TextBox txtotp;
        private LinkLabel linkLabel1;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
    }
