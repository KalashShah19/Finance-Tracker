﻿namespace login_windos
{
    partial class Dashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnreports = new Button();
            comboBox1 = new ComboBox();
            btnHistory = new Button();
            btnLogout = new Button();
            lblWelComeuser = new Label();
            btnBalance = new Button();
            lblPayTo = new Label();
            txtboxAccountNumber = new TextBox();
            txtboxAmount = new TextBox();
            lblAmount = new Label();
            btnTransfer = new Button();
            lblFullName = new Label();
            lblNote = new Label();
            txtboxNote = new TextBox();
            lnbFullName = new Label();
            label1 = new Label();
            lblName = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.Controls.Add(btnreports);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(btnHistory);
            panel1.Controls.Add(btnLogout);
            panel1.Controls.Add(lblWelComeuser);
            panel1.Location = new Point(1, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(706, 52);
            panel1.TabIndex = 0;
            // 
            // btnreports
            // 
            btnreports.BackColor = SystemColors.ButtonFace;
            btnreports.Location = new Point(414, 11);
            btnreports.Margin = new Padding(3, 4, 3, 4);
            btnreports.Name = "btnreports";
            btnreports.Size = new Size(86, 31);
            btnreports.TabIndex = 6;
            btnreports.Text = "Reports";
            btnreports.UseVisualStyleBackColor = false;
            btnreports.Click += btnreports_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Change Password", "Update Bank Details", "Update Profile Details" });
            comboBox1.Location = new Point(156, 13);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(202, 28);
            comboBox1.TabIndex = 5;
            comboBox1.Text = "Settings";
            comboBox1.SelectionChangeCommitted += SelectSettings;
            // 
            // btnHistory
            // 
            btnHistory.BackColor = SystemColors.ButtonFace;
            btnHistory.Location = new Point(506, 11);
            btnHistory.Margin = new Padding(3, 4, 3, 4);
            btnHistory.Name = "btnHistory";
            btnHistory.Size = new Size(86, 31);
            btnHistory.TabIndex = 1;
            btnHistory.Text = "History";
            btnHistory.UseVisualStyleBackColor = false;
            btnHistory.Click += OpenHistory;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = SystemColors.ButtonFace;
            btnLogout.Location = new Point(608, 11);
            btnLogout.Margin = new Padding(3, 4, 3, 4);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(86, 31);
            btnLogout.TabIndex = 3;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // lblWelComeuser
            // 
            lblWelComeuser.AutoSize = true;
            lblWelComeuser.Location = new Point(43, 16);
            lblWelComeuser.Name = "lblWelComeuser";
            lblWelComeuser.Size = new Size(107, 20);
            lblWelComeuser.TabIndex = 4;
            lblWelComeuser.Text = "WelCome user,";
            // 
            // btnBalance
            // 
            btnBalance.BackColor = SystemColors.ButtonFace;
            btnBalance.Location = new Point(578, 60);
            btnBalance.Margin = new Padding(3, 4, 3, 4);
            btnBalance.Name = "btnBalance";
            btnBalance.Size = new Size(86, 31);
            btnBalance.TabIndex = 4;
            btnBalance.Text = "Balance";
            btnBalance.UseVisualStyleBackColor = false;
            // 
            // lblPayTo
            // 
            lblPayTo.AutoSize = true;
            lblPayTo.Location = new Point(130, 121);
            lblPayTo.Name = "lblPayTo";
            lblPayTo.Size = new Size(121, 20);
            lblPayTo.TabIndex = 6;
            lblPayTo.Text = "Account Number";
            // 
            // txtboxAccountNumber
            // 
            txtboxAccountNumber.Location = new Point(248, 117);
            txtboxAccountNumber.Margin = new Padding(3, 4, 3, 4);
            txtboxAccountNumber.Name = "txtboxAccountNumber";
            txtboxAccountNumber.Size = new Size(150, 27);
            txtboxAccountNumber.TabIndex = 7;
            txtboxAccountNumber.TextChanged += txtboxAccountNumber_TextChanged;
            // 
            // txtboxAmount
            // 
            txtboxAmount.Location = new Point(248, 169);
            txtboxAmount.Margin = new Padding(3, 4, 3, 4);
            txtboxAmount.Name = "txtboxAmount";
            txtboxAmount.Size = new Size(150, 27);
            txtboxAmount.TabIndex = 8;
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Location = new Point(130, 173);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(62, 20);
            lblAmount.TabIndex = 9;
            lblAmount.Text = "Amount";
            lblAmount.TextAlign = ContentAlignment.TopCenter;
            // 
            // btnTransfer
            // 
            btnTransfer.BackColor = SystemColors.ButtonFace;
            btnTransfer.Location = new Point(248, 323);
            btnTransfer.Margin = new Padding(3, 4, 3, 4);
            btnTransfer.Name = "btnTransfer";
            btnTransfer.Size = new Size(151, 31);
            btnTransfer.TabIndex = 10;
            btnTransfer.Text = "Transfer";
            btnTransfer.UseVisualStyleBackColor = false;
            btnTransfer.Click += btnTransfer_Click_1;
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Location = new Point(130, 224);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(106, 20);
            lblFullName.TabIndex = 11;
            lblFullName.Text = "Banking Name";
            // 
            // lblNote
            // 
            lblNote.AutoSize = true;
            lblNote.Location = new Point(130, 275);
            lblNote.Name = "lblNote";
            lblNote.Size = new Size(42, 20);
            lblNote.TabIndex = 12;
            lblNote.Text = "Note";
            // 
            // txtboxNote
            // 
            txtboxNote.Location = new Point(248, 264);
            txtboxNote.Margin = new Padding(3, 4, 3, 4);
            txtboxNote.Name = "txtboxNote";
            txtboxNote.Size = new Size(150, 27);
            txtboxNote.TabIndex = 13;
            // 
            // lnbFullName
            // 
            lnbFullName.AutoSize = true;
            lnbFullName.Location = new Point(248, 224);
            lnbFullName.Name = "lnbFullName";
            lnbFullName.Size = new Size(0, 20);
            lnbFullName.TabIndex = 14;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(248, 71);
            label1.Name = "label1";
            label1.Size = new Size(61, 20);
            label1.TabIndex = 15;
            label1.Text = "Transfer";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(419, 121);
            lblName.Name = "lblName";
            lblName.Size = new Size(0, 20);
            lblName.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(507, 65);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 17;
            label2.Text = "Balance:";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(707, 379);
            Controls.Add(label2);
            Controls.Add(lblName);
            Controls.Add(label1);
            Controls.Add(lnbFullName);
            Controls.Add(txtboxNote);
            Controls.Add(lblNote);
            Controls.Add(lblFullName);
            Controls.Add(btnTransfer);
            Controls.Add(lblAmount);
            Controls.Add(txtboxAmount);
            Controls.Add(txtboxAccountNumber);
            Controls.Add(lblPayTo);
            Controls.Add(btnBalance);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Dashboard";
            Text = "Finance Tracker";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnLogout;
        private Button btnHistory;
        private Label lblWelComeuser;
        private Button btnBalance;
        private TextBox txtboxNote;
        private Label lblPayTo;
        private TextBox txtboxAccountNumber;
        private TextBox txtboxAmount;
        private Label lblAmount;
        private Button btnTransfer;
        private Label lblFullName;
        private Label lblNote;
        private Label lnbFullName;
        private Label label1;
        private ComboBox comboBox1;
        private Label lblName;
        private Button btnreports;
        private Label label2;
    }
}
