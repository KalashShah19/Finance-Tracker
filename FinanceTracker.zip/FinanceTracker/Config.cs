public static class Config
{
    //public static string ConnectionString = "Server=cipg01;port=5432;Database=finance;UserId=postgres;Password=123456;";
    public static string ConnectionString = "Server=cipg01;port=5432;Database=Anvi081;User Id=postgres;Password=123456;";
    public static string imagePath = @"C:\Users\Admin\source\repos\FinanceTracker\Finance\images\";
    public static string emailTemplatePath = @"C:\Users\Admin\source\repos\FinanceTracker\Finance\index.html";
}
