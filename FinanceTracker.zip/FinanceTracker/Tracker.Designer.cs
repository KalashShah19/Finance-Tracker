using static System.Net.Mime.MediaTypeNames;
using System.Windows.Forms;
using System.Xml.Linq;
using Font = System.Drawing.Font;

namespace login_windos
{
    partial class Tracker
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblregistration = new Label();
            lblfirstname = new Label();
            lbllastname = new Label();
            lblcontact = new Label();
            lbldob = new Label();
            lblemail = new Label();
            lblprofile = new Label();
            lblpassword = new Label();
            lblcnfpassword = new Label();
            lblacc_no = new Label();
            lblbank_name = new Label();
            lblifce_code = new Label();
            txtfname = new TextBox();
            txtlname = new TextBox();
            txtcontact = new TextBox();
            txtmail = new TextBox();
            txtpassword = new TextBox();
            txtcnfpassword = new TextBox();
            txtacc_no = new TextBox();
            txtifsccode = new TextBox();
            dtpdob = new DateTimePicker();
            ddbankname = new ComboBox();
            lblbankdetails = new Label();
            pictureBox1 = new PictureBox();
            btnupload = new Button();
            progressBar1 = new ProgressBar();
            btnregister = new Button();
            lblallreadyreg = new Label();
            linklogin = new LinkLabel();
            chktc = new CheckBox();
            linkterm = new LinkLabel();
            msgfname = new Label();
            msglname = new Label();
            msgphonenumber = new Label();
            msgdob = new Label();
            msgemail = new Label();
            msgpassword = new Label();
            msgcnfpassword = new Label();
            msgprofile = new Label();
            msgacc_no = new Label();
            msgbank = new Label();
            msgifsc = new Label();
            msgchkterm = new Label();
            chkshow = new CheckBox();
            chkshow2 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblregistration
            // 
            lblregistration.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblregistration.Location = new Point(598, 60);
            lblregistration.Name = "lblregistration";
            lblregistration.Size = new Size(211, 39);
            lblregistration.TabIndex = 0;
            lblregistration.Text = "Registration Form";
            lblregistration.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblfirstname
            // 
            lblfirstname.AutoSize = true;
            lblfirstname.Location = new Point(121, 151);
            lblfirstname.Name = "lblfirstname";
            lblfirstname.Size = new Size(80, 20);
            lblfirstname.TabIndex = 1;
            lblfirstname.Text = "First Name";
            // 
            // lbllastname
            // 
            lbllastname.AutoSize = true;
            lbllastname.Location = new Point(121, 233);
            lbllastname.Name = "lbllastname";
            lbllastname.Size = new Size(79, 20);
            lbllastname.TabIndex = 2;
            lbllastname.Text = "Last Name";
            // 
            // lblcontact
            // 
            lblcontact.AutoSize = true;
            lblcontact.Location = new Point(121, 292);
            lblcontact.Name = "lblcontact";
            lblcontact.Size = new Size(77, 20);
            lblcontact.TabIndex = 3;
            lblcontact.Text = "Phone No.";
            // 
            // lbldob
            // 
            lbldob.AutoSize = true;
            lbldob.Location = new Point(121, 360);
            lbldob.Name = "lbldob";
            lbldob.Size = new Size(96, 20);
            lbldob.TabIndex = 4;
            lbldob.Text = "Date Of Birth";
            // 
            // lblemail
            // 
            lblemail.AutoSize = true;
            lblemail.Location = new Point(121, 437);
            lblemail.Name = "lblemail";
            lblemail.Size = new Size(46, 20);
            lblemail.TabIndex = 5;
            lblemail.Text = "Email";
            // 
            // lblprofile
            // 
            lblprofile.AutoSize = true;
            lblprofile.Location = new Point(755, 161);
            lblprofile.Name = "lblprofile";
            lblprofile.Size = new Size(59, 20);
            lblprofile.TabIndex = 6;
            lblprofile.Text = "Profile :";
            // 
            // lblpassword
            // 
            lblpassword.AutoSize = true;
            lblpassword.Location = new Point(121, 512);
            lblpassword.Name = "lblpassword";
            lblpassword.Size = new Size(70, 20);
            lblpassword.TabIndex = 7;
            lblpassword.Text = "Password";
            // 
            // lblcnfpassword
            // 
            lblcnfpassword.AutoSize = true;
            lblcnfpassword.Location = new Point(121, 575);
            lblcnfpassword.Name = "lblcnfpassword";
            lblcnfpassword.Size = new Size(127, 20);
            lblcnfpassword.TabIndex = 8;
            lblcnfpassword.Text = "Confirm Password";
            // 
            // lblacc_no
            // 
            lblacc_no.AutoSize = true;
            lblacc_no.Location = new Point(755, 395);
            lblacc_no.Name = "lblacc_no";
            lblacc_no.Size = new Size(121, 20);
            lblacc_no.TabIndex = 9;
            lblacc_no.Text = "Account Number";
            // 
            // lblbank_name
            // 
            lblbank_name.AutoSize = true;
            lblbank_name.Location = new Point(755, 459);
            lblbank_name.Name = "lblbank_name";
            lblbank_name.Size = new Size(85, 20);
            lblbank_name.TabIndex = 10;
            lblbank_name.Text = "Bank Name";
            // 
            // lblifce_code
            // 
            lblifce_code.AutoSize = true;
            lblifce_code.Location = new Point(755, 532);
            lblifce_code.Name = "lblifce_code";
            lblifce_code.Size = new Size(76, 20);
            lblifce_code.TabIndex = 11;
            lblifce_code.Text = "IFSC Code";
            // 
            // txtfname
            // 
            txtfname.Location = new Point(333, 151);
            txtfname.Margin = new Padding(3, 4, 3, 4);
            txtfname.Name = "txtfname";
            txtfname.Size = new Size(286, 27);
            txtfname.TabIndex = 12;
            txtfname.TextChanged += txtfname_TextChanged;
            // 
            // txtlname
            // 
            txtlname.Location = new Point(333, 223);
            txtlname.Margin = new Padding(3, 4, 3, 4);
            txtlname.Name = "txtlname";
            txtlname.Size = new Size(286, 27);
            txtlname.TabIndex = 13;
            txtlname.TextChanged += txtlname_TextChanged;
            // 
            // txtcontact
            // 
            txtcontact.Location = new Point(333, 288);
            txtcontact.Margin = new Padding(3, 4, 3, 4);
            txtcontact.Name = "txtcontact";
            txtcontact.Size = new Size(286, 27);
            txtcontact.TabIndex = 14;
            txtcontact.TextChanged += txtcontact_TextChanged;
            // 
            // txtmail
            // 
            txtmail.Location = new Point(333, 433);
            txtmail.Margin = new Padding(3, 4, 3, 4);
            txtmail.Name = "txtmail";
            txtmail.Size = new Size(286, 27);
            txtmail.TabIndex = 15;
            txtmail.TextChanged += txtmail_TextChanged;
            // 
            // txtpassword
            // 
            txtpassword.Location = new Point(333, 501);
            txtpassword.Margin = new Padding(3, 4, 3, 4);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(286, 27);
            txtpassword.TabIndex = 16;
            txtpassword.UseSystemPasswordChar = true;
            txtpassword.TextChanged += txtpassword_TextChanged;
            // 
            // txtcnfpassword
            // 
            txtcnfpassword.Location = new Point(333, 564);
            txtcnfpassword.Margin = new Padding(3, 4, 3, 4);
            txtcnfpassword.Name = "txtcnfpassword";
            txtcnfpassword.Size = new Size(286, 27);
            txtcnfpassword.TabIndex = 17;
            txtcnfpassword.UseSystemPasswordChar = true;
            txtcnfpassword.TextChanged += txtcnfpassword_TextChanged;
            // 
            // txtacc_no
            // 
            txtacc_no.Location = new Point(879, 388);
            txtacc_no.Margin = new Padding(3, 4, 3, 4);
            txtacc_no.Name = "txtacc_no";
            txtacc_no.Size = new Size(286, 27);
            txtacc_no.TabIndex = 18;
            txtacc_no.TextChanged += txtacc_no_TextChanged;
            // 
            // txtifsccode
            // 
            txtifsccode.Location = new Point(879, 525);
            txtifsccode.Margin = new Padding(3, 4, 3, 4);
            txtifsccode.Name = "txtifsccode";
            txtifsccode.Size = new Size(286, 27);
            txtifsccode.TabIndex = 19;
            txtifsccode.TextChanged += txtifsccode_TextChanged;
            // 
            // dtpdob
            // 
            dtpdob.Location = new Point(333, 360);
            dtpdob.Margin = new Padding(3, 4, 3, 4);
            dtpdob.MaxDate = new DateTime(2024, 9, 29, 0, 0, 0, 0);
            dtpdob.MinDate = new DateTime(1960, 1, 1, 0, 0, 0, 0);
            dtpdob.Name = "dtpdob";
            dtpdob.Size = new Size(286, 27);
            dtpdob.TabIndex = 20;
            dtpdob.Value = new DateTime(2024, 9, 29, 0, 0, 0, 0);
            dtpdob.ValueChanged += dtpdob_ValueChanged;
            // 
            // ddbankname
            // 
            ddbankname.FormattingEnabled = true;
            ddbankname.Items.AddRange(new object[] { "State Bank Of India", "Bank Of Baroda", "Axis Bank", "ICICI Bank" });
            ddbankname.Location = new Point(879, 463);
            ddbankname.Margin = new Padding(3, 4, 3, 4);
            ddbankname.Name = "ddbankname";
            ddbankname.Size = new Size(286, 28);
            ddbankname.TabIndex = 21;
            // 
            // lblbankdetails
            // 
            lblbankdetails.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblbankdetails.Location = new Point(893, 329);
            lblbankdetails.Name = "lblbankdetails";
            lblbankdetails.Padding = new Padding(6, 7, 6, 7);
            lblbankdetails.Size = new Size(216, 55);
            lblbankdetails.TabIndex = 22;
            lblbankdetails.Text = "Bank Details";
            lblbankdetails.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(843, 151);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(144, 167);
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // btnupload
            // 
            btnupload.BackColor = SystemColors.ActiveCaption;
            btnupload.Location = new Point(1037, 204);
            btnupload.Margin = new Padding(3, 4, 3, 4);
            btnupload.Name = "btnupload";
            btnupload.Size = new Size(102, 43);
            btnupload.TabIndex = 24;
            btnupload.Text = "Upload";
            btnupload.UseVisualStyleBackColor = false;
            btnupload.Click += btnupload_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(1006, 288);
            progressBar1.Margin = new Padding(3, 4, 3, 4);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(160, 31);
            progressBar1.TabIndex = 25;
            // 
            // btnregister
            // 
            btnregister.BackColor = SystemColors.ActiveCaption;
            btnregister.Location = new Point(626, 716);
            btnregister.Margin = new Padding(3, 4, 3, 4);
            btnregister.Name = "btnregister";
            btnregister.Size = new Size(137, 49);
            btnregister.TabIndex = 26;
            btnregister.Text = "Register";
            btnregister.UseVisualStyleBackColor = false;
            btnregister.Click += btnregister_Click;
            // 
            // lblallreadyreg
            // 
            lblallreadyreg.AutoSize = true;
            lblallreadyreg.Location = new Point(579, 776);
            lblallreadyreg.Name = "lblallreadyreg";
            lblallreadyreg.Size = new Size(146, 20);
            lblallreadyreg.TabIndex = 27;
            lblallreadyreg.Text = "Allready Registered?";
            // 
            // linklogin
            // 
            linklogin.AutoSize = true;
            linklogin.Location = new Point(722, 776);
            linklogin.Name = "linklogin";
            linklogin.Size = new Size(76, 20);
            linklogin.TabIndex = 28;
            linklogin.TabStop = true;
            linklogin.Text = "Click Here";
            linklogin.Click += Click_here;
            // 
            // chktc
            // 
            chktc.AutoSize = true;
            chktc.Location = new Point(126, 660);
            chktc.Margin = new Padding(3, 4, 3, 4);
            chktc.Name = "chktc";
            chktc.Size = new Size(18, 17);
            chktc.TabIndex = 29;
            chktc.UseVisualStyleBackColor = true;
            // 
            // linkterm
            // 
            linkterm.AutoSize = true;
            linkterm.LinkColor = Color.Black;
            linkterm.Location = new Point(150, 660);
            linkterm.Name = "linkterm";
            linkterm.Size = new Size(152, 20);
            linkterm.TabIndex = 30;
            linkterm.TabStop = true;
            linkterm.Text = "Terms and Conditions";
            linkterm.LinkClicked += linkterm_LinkClicked;
            // 
            // msgfname
            // 
            msgfname.AutoSize = true;
            msgfname.Location = new Point(336, 185);
            msgfname.Name = "msgfname";
            msgfname.Size = new Size(0, 20);
            msgfname.TabIndex = 31;
            // 
            // msglname
            // 
            msglname.AutoSize = true;
            msglname.Location = new Point(338, 257);
            msglname.Name = "msglname";
            msglname.Size = new Size(0, 20);
            msglname.TabIndex = 32;
            // 
            // msgphonenumber
            // 
            msgphonenumber.AutoSize = true;
            msgphonenumber.Location = new Point(337, 323);
            msgphonenumber.Name = "msgphonenumber";
            msgphonenumber.Size = new Size(0, 20);
            msgphonenumber.TabIndex = 33;
            // 
            // msgdob
            // 
            msgdob.AutoSize = true;
            msgdob.Location = new Point(336, 395);
            msgdob.Name = "msgdob";
            msgdob.Size = new Size(0, 20);
            msgdob.TabIndex = 34;
            // 
            // msgemail
            // 
            msgemail.AutoSize = true;
            msgemail.Location = new Point(337, 467);
            msgemail.Name = "msgemail";
            msgemail.Size = new Size(0, 20);
            msgemail.TabIndex = 35;
            // 
            // msgpassword
            // 
            msgpassword.AutoSize = true;
            msgpassword.Location = new Point(338, 535);
            msgpassword.Name = "msgpassword";
            msgpassword.Size = new Size(0, 20);
            msgpassword.TabIndex = 36;
            // 
            // msgcnfpassword
            // 
            msgcnfpassword.AutoSize = true;
            msgcnfpassword.Location = new Point(337, 599);
            msgcnfpassword.Name = "msgcnfpassword";
            msgcnfpassword.Size = new Size(0, 20);
            msgcnfpassword.TabIndex = 37;
            // 
            // msgprofile
            // 
            msgprofile.AutoSize = true;
            msgprofile.Location = new Point(1009, 261);
            msgprofile.Name = "msgprofile";
            msgprofile.Size = new Size(0, 20);
            msgprofile.TabIndex = 38;
            // 
            // msgacc_no
            // 
            msgacc_no.AutoSize = true;
            msgacc_no.Location = new Point(883, 423);
            msgacc_no.Name = "msgacc_no";
            msgacc_no.Size = new Size(0, 20);
            msgacc_no.TabIndex = 39;
            // 
            // msgbank
            // 
            msgbank.AutoSize = true;
            msgbank.Location = new Point(883, 496);
            msgbank.Name = "msgbank";
            msgbank.Size = new Size(0, 20);
            msgbank.TabIndex = 40;
            // 
            // msgifsc
            // 
            msgifsc.AutoSize = true;
            msgifsc.Location = new Point(886, 560);
            msgifsc.Name = "msgifsc";
            msgifsc.Size = new Size(0, 20);
            msgifsc.TabIndex = 41;
            // 
            // msgchkterm
            // 
            msgchkterm.AutoSize = true;
            msgchkterm.Location = new Point(157, 689);
            msgchkterm.Name = "msgchkterm";
            msgchkterm.Size = new Size(0, 20);
            msgchkterm.TabIndex = 42;
            // 
            // chkshow
            // 
            chkshow.AutoSize = true;
            chkshow.Location = new Point(641, 504);
            chkshow.Name = "chkshow";
            chkshow.Size = new Size(67, 24);
            chkshow.TabIndex = 43;
            chkshow.Text = "Show";
            chkshow.UseVisualStyleBackColor = true;
            chkshow.CheckedChanged += chkshow_CheckedChanged;
            // 
            // chkshow2
            // 
            chkshow2.AutoSize = true;
            chkshow2.Location = new Point(641, 566);
            chkshow2.Name = "chkshow2";
            chkshow2.Size = new Size(67, 24);
            chkshow2.TabIndex = 44;
            chkshow2.Text = "Show";
            chkshow2.UseVisualStyleBackColor = true;
            chkshow2.CheckedChanged += chkshow2_CheckedChanged;
            // 
            // Tracker
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1347, 891);
            Controls.Add(chkshow2);
            Controls.Add(chkshow);
            Controls.Add(msgchkterm);
            Controls.Add(msgifsc);
            Controls.Add(msgbank);
            Controls.Add(msgacc_no);
            Controls.Add(msgprofile);
            Controls.Add(msgcnfpassword);
            Controls.Add(msgpassword);
            Controls.Add(msgemail);
            Controls.Add(msgdob);
            Controls.Add(msgphonenumber);
            Controls.Add(msglname);
            Controls.Add(msgfname);
            Controls.Add(linkterm);
            Controls.Add(chktc);
            Controls.Add(linklogin);
            Controls.Add(lblallreadyreg);
            Controls.Add(btnregister);
            Controls.Add(progressBar1);
            Controls.Add(btnupload);
            Controls.Add(pictureBox1);
            Controls.Add(lblbankdetails);
            Controls.Add(ddbankname);
            Controls.Add(dtpdob);
            Controls.Add(txtifsccode);
            Controls.Add(txtacc_no);
            Controls.Add(txtcnfpassword);
            Controls.Add(txtpassword);
            Controls.Add(txtmail);
            Controls.Add(txtcontact);
            Controls.Add(txtlname);
            Controls.Add(txtfname);
            Controls.Add(lblifce_code);
            Controls.Add(lblbank_name);
            Controls.Add(lblacc_no);
            Controls.Add(lblcnfpassword);
            Controls.Add(lblpassword);
            Controls.Add(lblprofile);
            Controls.Add(lblemail);
            Controls.Add(lbldob);
            Controls.Add(lblcontact);
            Controls.Add(lbllastname);
            Controls.Add(lblfirstname);
            Controls.Add(lblregistration);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Tracker";
            Text = "Tracker";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblregistration;
        private Label lblfirstname;
        private Label lbllastname;
        private Label lblcontact;
        private Label lbldob;
        private Label lblemail;
        private Label lblprofile;
        private Label lblpassword;
        private Label lblcnfpassoword;
        private Label lblacc_no;
        private Label lblbank_name;
        private Label lblifce_code;
        private TextBox txtfname;
        private TextBox txtlname;
        private TextBox txtcontact;
        private TextBox txtmail;
        private TextBox txtpassword;
        private TextBox txtcnfpassword;
        private TextBox txtacc_no;
        private TextBox txtifsccode;
        private DateTimePicker dtpdob;
        private ComboBox ddbankname;
        private Label lblbankdetails;
        private PictureBox pictureBox1;
        private Button btnupload;
        private ProgressBar progressBar1;
        private Button btnregister;
        private Label lblallreadyreg;
        private LinkLabel linklogin;
        private CheckBox chktc;
        private LinkLabel linkterm;
        private Label msgfname;
        private Label msglname;
        private Label msgphonenumber;
        private Label msgdob;
        private Label msgemail;
        private Label msgpassword;
        private Label msgcnfpassword;
        private Label msgprofile;
        private Label msgacc_no;
        private Label msgbank;
        private Label msgifsc;
        private Label msgchkterm;
        private Label lblcnfpassword;
        private CheckBox chkshow;
        private CheckBox chkshow2;
    }

}