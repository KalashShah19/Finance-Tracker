﻿using System.Windows.Forms;
using System.Xml.Linq;

namespace login_windos
{

    partial class BarChart
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BarChartExpense = new MindFusion.Charting.WinForms.BarChart();
            btnDownload = new Button();
            lblTitle = new Label();
            SuspendLayout();
            // 
            // BarChartExpense
            // 
            BarChartExpense.LegendTitle = "Legend";
            BarChartExpense.Location = new Point(189, 42);
            BarChartExpense.Name = "BarChartExpense";
            BarChartExpense.Padding = new Padding(5);
            BarChartExpense.ShowLegend = true;
            BarChartExpense.Size = new Size(496, 358);
            BarChartExpense.SubtitleFontName = null;
            BarChartExpense.SubtitleFontSize = null;
            BarChartExpense.SubtitleFontStyle = null;
            BarChartExpense.TabIndex = 0;
            BarChartExpense.Text = "pieChart1";
            BarChartExpense.Theme.UniformSeriesFill = new MindFusion.Drawing.SolidBrush("#FF90EE90");
            BarChartExpense.Theme.UniformSeriesStroke = new MindFusion.Drawing.SolidBrush("#FF000000");
            BarChartExpense.Theme.UniformSeriesStrokeThickness = 2D;
            BarChartExpense.TitleFontName = null;
            BarChartExpense.TitleFontSize = null;
            BarChartExpense.TitleFontStyle = null;
            // 
            // btnDownload
            // 
            btnDownload.Location = new Point(367, 415);
            btnDownload.Name = "btnDownload";
            btnDownload.Size = new Size(142, 23);
            btnDownload.TabIndex = 4;
            btnDownload.Text = "Download Report";
            btnDownload.UseVisualStyleBackColor = true;
            btnDownload.Click += btnDownloadBarChart_Click;

            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(343, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(166, 25);
            lblTitle.TabIndex = 6;
            lblTitle.Text = "Expense Bar Chart";
            // 
            // PieChart
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTitle);
            Controls.Add(btnDownload);
            Controls.Add(BarChartExpense);
            Name = "BarChart";
            Text = "BarChart";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MindFusion.Charting.WinForms.BarChart BarChartExpense;
        private Button btnDownload;
        private Label lblTitle;

    }
}