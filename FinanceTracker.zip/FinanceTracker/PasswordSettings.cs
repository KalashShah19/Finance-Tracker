﻿using Npgsql;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Project
{
    public partial class PasswordSettings : Form
    {
        readonly int userid;
        readonly NpgsqlConnection connection;
        public PasswordSettings(int userid)
        {
            InitializeComponent();
            string connectionString = Config.ConnectionString;
            this.userid = userid;
            NpgsqlDataSource dataSource = NpgsqlDataSource.Create(connectionString);
            this.connection = dataSource.OpenConnection();
        }

        public new bool Validate()
        {
            if (string.IsNullOrEmpty(tb_current_password.Text) || !Regex.IsMatch(tb_current_password.Text, @"^[0-9]{4}$"))
            {
                MessageBox.Show("Enter a valid current pin (4 digits only)");
                return false;
            }
            else if (string.IsNullOrEmpty(tb_new_password.Text) || !Regex.IsMatch(tb_new_password.Text, @"^[0-9]{4}$"))
            {
                MessageBox.Show("Enter a valid new pin (4 digits only)");
                return false;
            }
            else if (!Regex.IsMatch(tb_confirm_password.Text, @"^[0-9]{4}$") || !string.Equals(tb_new_password.Text, tb_confirm_password.Text))
            {
                MessageBox.Show("Pin do not match");
                return false;
            }
            return true;
        }

        public bool CheckCurrentPassword()
        {
            NpgsqlCommand command = new("SELECT COUNT(c_id) FROM t_customer WHERE c_id = @id AND c_pin = @password", connection);
            command.Parameters.AddWithValue("id", userid);
            command.Parameters.AddWithValue("password", MD5Hash(tb_current_password.Text));
            NpgsqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                bool result = (reader.GetInt32(0) == 1);
                reader.Close();
                return result;
            }
            reader.Close();
            return false;
        }

        public static string MD5Hash(string text)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            return sb.ToString();
        }

        public void UpdatePassword(object sender, EventArgs e)
        {
            if (!Validate()) return;
            if (!CheckCurrentPassword())
            {
                MessageBox.Show("Incorrect Pin");
                return;
            }
            NpgsqlCommand command = new("UPDATE t_customer SET c_pin = @password WHERE c_id = @id", connection);
            command.Parameters.AddWithValue("password", MD5Hash(tb_new_password.Text));
            command.Parameters.AddWithValue("id", userid);
            command.ExecuteNonQuery();
            MessageBox.Show("Pin updated successfully");
            this.Close();
        }
    }
}
