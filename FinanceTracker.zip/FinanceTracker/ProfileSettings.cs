using Npgsql;
using System.Text.RegularExpressions;

namespace Project;

public partial class ProfileSettings : Form
{
    readonly NpgsqlConnection connection;
    string filename = "";
    readonly int userid;
    public ProfileSettings(int userid)
    {
        InitializeComponent();
        string connectionString = Config.ConnectionString;
        this.userid = userid;
        NpgsqlDataSource dataSource = NpgsqlDataSource.Create(connectionString);
        this.connection = dataSource.OpenConnection();
        if (!Directory.Exists(Config.imagePath)) Directory.CreateDirectory(Config.imagePath);
        GetUserData();
    }

    public void GetUserData()
    {
        NpgsqlCommand command = new("SELECT c_profile_image, c_fname, c_lname, c_contact, c_dob, c_email, c_dark_theme FROM t_customer WHERE c_id = @id", connection);
        command.Parameters.AddWithValue("id", this.userid);
        NpgsqlDataReader reader = command.ExecuteReader();
        if (reader.Read())
        {
            pb_image.ImageLocation = reader.GetString(0);
            lb_showname.Text = $"{reader.GetString(1)} {reader.GetString(2)}";
            tb_contact.Text = reader.GetInt64(3).ToString();
            lb_showdob.Text = reader.GetDateTime(4).ToShortDateString();
            lb_showemail.Text = reader.GetString(5);
            cb_darkmode.Checked = reader.GetBoolean(6);
        }
        reader.Close();
    }

    public void GetTheme()
    {
        NpgsqlCommand command = new("SELECT c_dark_theme FROM t_customer WHERE c_id = @id", connection);
        command.Parameters.AddWithValue("id", this.userid);
        NpgsqlDataReader reader = command.ExecuteReader();
        if (reader.Read())
        {
            MessageBox.Show(reader.GetBoolean(0).ToString());
        }
    }

    public new bool Validate()
    {
        if (pb_image.ImageLocation == "")
        {
            MessageBox.Show("Please select a valid picture");
            return false;
        }
        else if (string.IsNullOrEmpty(tb_contact.Text) || !Regex.IsMatch(tb_contact.Text, @"^[0-9]{10}$"))
        {
            MessageBox.Show("Please enter your valid contact number");
            return false;
        }

        return true;
    }

    public void PickImageHelper(object sender, EventArgs e)
    {
        Thread thread = new Thread(PickImage);
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        thread.Join();
    }

    public void PickImage()
    {
        OpenFileDialog fileDialog = new OpenFileDialog();
        fileDialog.ShowHelp = true;
        if (fileDialog.ShowDialog() == DialogResult.OK)
        {
            pb_image.ImageLocation = fileDialog.FileName;
            filename = fileDialog.SafeFileName;
        }
    }

    public void UpdateUserData(object sender, EventArgs e)
    {
        if (!Validate()) return;
        NpgsqlCommand command = new("UPDATE t_customer SET " + (string.IsNullOrEmpty(filename) ? "" : "c_profile_image = @image, ") + "c_contact = @contact, c_dark_theme = @darktheme WHERE c_id = @id", connection);
        if (!string.IsNullOrEmpty(filename)) command.Parameters.AddWithValue("image", $"{Config.imagePath}{this.filename}");
        command.Parameters.AddWithValue("contact", long.Parse(tb_contact.Text));
        command.Parameters.AddWithValue("darktheme", cb_darkmode.Checked);
        command.Parameters.AddWithValue("id", this.userid);
        command.ExecuteNonQuery();

        // MessageBox.Show(this.filename);
        
        
        if (!File.Exists($"{Config.imagePath}{this.filename}") && !string.IsNullOrEmpty(filename)) File.Copy(pb_image.ImageLocation, $"{Config.imagePath}{this.filename}");
        MessageBox.Show("Updated Successfully !");
        this.Close();
    }

}
