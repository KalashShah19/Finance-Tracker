using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Npgsql;
using System.Security.Cryptography;
using login_windos;

namespace demo
{
    public partial class forgetpass : Form
    {
        NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);
        string passwordmatch;
        string passwordtonew;
        bool passworddone = false;
        bool newpassworddone = false;
        bool falset = false;
        private string email;
        private int customerId;

        public forgetpass(string email, int customerId)
        {
            InitializeComponent();
            this.email = email;
            this.customerId = customerId;
            //lblnewpassword.Text=email+customerId.ToString();
        }

        public void checkbox_checked_change(object sender, EventArgs e)
        {
            if (check_password.Checked)
            {

                txtpassword.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
            }


        }
        public void password_chek_onchanged(object sender, EventArgs e)
        {

            string passwordPattern = @"^\d{4}$";
            bool isValidPassword = Regex.IsMatch(txtpassword.Text, passwordPattern);
            string passwordMessage = "Input must be exactly 4 digits.";

            string message = isValidPassword ? "" : passwordMessage;
            label3.ForeColor = System.Drawing.Color.Red;
            if (message == "")
            {
                passwordmatch = txtpassword.Text;
                passworddone = true;

                if (falset)
                {
                    password_chek_new_onchanged1();
                }


            }
            label3.Text = message;


        }

        private void password_chek_new_onchanged1()
        {

            string passwordPattern = @"^\d{4}$";
            bool isValidPassword = Regex.IsMatch(txtpassword.Text, passwordPattern);
            string passwordMessage = "Input must be exactly 4 digits.";
            passwordtonew = txtnewpassword.Text.ToString();
            // lblnewpassword.Text = passwordmatch + "=" + passwordtonew;
            bool passwordismatch = passwordmatch.Equals(passwordtonew);

            string message = passwordismatch && isValidPassword ? "" : "Pin Number do not match" + passwordMessage;

            label4.ForeColor = System.Drawing.Color.Red;
            label4.Text = message;
        }

        public void password_chek_new_onchanged(object sender, EventArgs e)
        {
            falset = true;
            string passwordPattern = @"^\d{4}$";
            bool isValidPassword = Regex.IsMatch(txtpassword.Text, passwordPattern);
            string passwordMessage = "Input must be exactly 4 digits.";
            passwordtonew = txtnewpassword.Text.ToString();
            // lblnewpassword.Text = passwordmatch + "=" + passwordtonew;
            bool passwordismatch = passwordmatch.Equals(passwordtonew);

            string message = passwordismatch && isValidPassword ? "" : "Pin Number do not match" + passwordMessage;

            label4.ForeColor = System.Drawing.Color.Red;
            label4.Text = message;





        }
        public void checkbox_checked_new_change(object sender, EventArgs e)
        {
            if (check_new_password.Checked)
            {

                txtnewpassword.PasswordChar = '\0';
            }
            else
            {
                txtnewpassword.PasswordChar = '*';
            }

        }

        public void submit_click(object sender, EventArgs e)
        {

            if (passwordmatch == passwordtonew)
            {
                MD5 md5 = MD5.Create();
                byte[] inputBytes = Encoding.ASCII.GetBytes(passwordmatch);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                string newpin = sb.ToString().Trim();

                try
                {
                    string query = "UPDATE t_customer SET c_pin=@newpin WHERE c_id=@c_id AND c_email=@c_email";

                    // Open connection
                    conn.Open();

                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        // Add parameters with values
                        cmd.Parameters.AddWithValue("@newpin", newpin);  // new pin value
                        cmd.Parameters.AddWithValue("@c_id", customerId); // customer ID
                        cmd.Parameters.AddWithValue("@c_email", email);   // customer email

                        // Execute the update command
                        int rowsAffected = cmd.ExecuteNonQuery();

                        // Check if one row was updated
                        if (rowsAffected == 1)
                        {
                            MessageBox.Show("Pin changed successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                          this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Pin change failed. No record updated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Ensure the connection is closed
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }


            }
            else
            {
                MessageBox.Show("Pin Number do not match");
            }
        }


    }
}
