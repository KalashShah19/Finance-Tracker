﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MindFusion.Charting.Properties;
using Npgsql;

namespace login_windos
{
    public partial class Reports : Form
    {
        NpgsqlConnection connection = new NpgsqlConnection(Config.ConnectionString);

        public Reports()
        {
            InitializeComponent();
            ConfigureGrid(); this.Load += Reports_Load; // Attach the Load event
        }

        private void Reports_Load(object sender, EventArgs e)
        {
            LoadImages();
        }

        private void LoadImages()
        {
            try
            {


                // Or use a path if not using embedded resources
                pictureBox1.Image = Image.FromFile(Config.imagePath+ "exp pie.png");
                pictureBox3.Image = Image.FromFile(Config.imagePath + "line.png");
                pictureBox4.Image = Image.FromFile(Config.imagePath+"exp bar.png");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading images: " + ex.Message);
            }
        }
        private void ConfigureGrid()
        {
            budgetGridView.Columns.Add("Month", "Month");
            budgetGridView.Columns.Add("Income", "Income");
            budgetGridView.Columns.Add("Expenses", "Expenses");
            budgetGridView.Columns.Add("Savings", "Savings");

            budgetGridView.Rows.Clear();

            LoadDataFromDatabase();

        }

        private void LoadDataFromDatabase()
        {
            string connectionString = Config.ConnectionString;

            try
            {
                using (var con = new NpgsqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"
                    SELECT 
                    TO_CHAR(c_timestamp, 'Month YYYY') AS Month, 
                    SUM(CASE WHEN c_receiver = 1001 THEN c_amount ELSE 0 END) AS Income,
                    SUM(CASE WHEN c_sender = 1001 THEN c_amount ELSE 0 END) AS Expenses,
                    SUM(CASE WHEN c_receiver = 1001 THEN c_amount ELSE 0 END) - 
                    SUM(CASE WHEN c_sender = 1001 THEN c_amount ELSE 0 END) AS Savings
                    FROM t_transactions 
                    WHERE c_sender = 1001 OR c_receiver = 1001
                    GROUP BY Month
                    ORDER BY MIN(c_timestamp);";

                    using (var command = new NpgsqlCommand(query, con))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string month = reader["Month"].ToString()!;
                                string income = reader["Income"].ToString()!;
                                string expenses = reader["Expenses"].ToString()!;
                                string savings = reader["Savings"].ToString()!;

                                budgetGridView.Rows.Add(month, income, expenses, savings);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving data: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void btnPieChart_Click(object sender, EventArgs e)
        {
            PieChart form = new PieChart();
            form.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LineChart form = new LineChart();
            form.ShowDialog();
        }

        private void ExportDataToCSVUsingCopy(string filePath)
        {
            try
            {
                connection.Open();

                // string query = $"COPY (SELECT c_timestamp, c_sender, c_receiver, c_amount FROM t_transactions) TO '{filePath}' WITH CSV HEADER";
                // MessageBox.Show(query);

                // NpgsqlCommand cmd = new NpgsqlCommand(query, connection);
                // cmd.ExecuteNonQuery();

                string query = @"COPY ( SELECT 
                    TO_CHAR(c_timestamp, 'Month YYYY') AS Month, 
                    SUM(CASE WHEN c_receiver = 1001 THEN c_amount ELSE 0 END) AS Income,
                    SUM(CASE WHEN c_sender = 1001 THEN c_amount ELSE 0 END) AS Expenses,
                    SUM(CASE WHEN c_receiver = 1001 THEN c_amount ELSE 0 END) - 
                    SUM(CASE WHEN c_sender = 1001 THEN c_amount ELSE 0 END) AS Savings
                    FROM t_transactions 
                    WHERE c_sender = 1001 OR c_receiver = 1001
                    GROUP BY Month
                    ORDER BY MIN(c_timestamp)) TO STDOUT WITH CSV HEADER;";

                using (var writer = new StreamWriter(filePath))
                using (var copyOut = connection.BeginTextExport(query))
                {
                    writer.Write(copyOut.ReadToEnd());
                }

                MessageBox.Show("Data exported successfully to " + filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting data: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        private void btnExport_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog SaveFileDialog = new SaveFileDialog())
            {
                SaveFileDialog.Filter = "CSV file (.csv)|.csv";
                SaveFileDialog.Title = "Save the CSV file";
                SaveFileDialog.FileName = "demo";

                if (SaveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = SaveFileDialog.FileName;
                    ExportDataToCSVUsingCopy(filePath);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BarChart form = new BarChart();
            form.ShowDialog();
        }
    }
}
