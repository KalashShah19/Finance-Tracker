﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;

using MindFusion.Charting;
using Brush = MindFusion.Drawing.Brush;
using SolidBrush = MindFusion.Drawing.SolidBrush;


namespace login_windos
{
    public partial class LineChart : Form
    {
        System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();
        Random random = new Random();

        MyDateTimeSeries series1, series2, series3;

        public LineChart()
        {
            InitializeComponent();

            ObservableCollection<Series> data = new ObservableCollection<Series>();

            series1 = new MyDateTimeSeries(DateTime.Now, DateTime.Now, DateTime.Now.AddMinutes(1));
            series1.DateTimeFormat = DateTimeFormat.LongTime;
            series1.LabelInterval = 10;
            series1.MinValue = 0;
            series1.MaxValue = 120;
            series1.Title = "Savings";
            series1.SupportedLabels = LabelKinds.XAxisLabel;

            series2 = new MyDateTimeSeries(DateTime.Now, DateTime.Now, DateTime.Now.AddMinutes(1));
            series2.DateTimeFormat = DateTimeFormat.LongTime;
            series2.LabelInterval = 10;
            series2.MinValue = 0;
            series2.MaxValue = 120;
            series2.Title = "Expenses";
            series2.SupportedLabels = LabelKinds.None;

            series3 = new MyDateTimeSeries(DateTime.Now, DateTime.Now, DateTime.Now.AddMinutes(1));
            series3.DateTimeFormat = DateTimeFormat.LongTime;
            series3.LabelInterval = 10;
            series3.MinValue = 0;
            series3.MaxValue = 120;
            series3.Title = "Income";
            series3.SupportedLabels = LabelKinds.None;

            LineChartExpense.Series.Add(series1);
            LineChartExpense.Series.Add(series2);
            LineChartExpense.Series.Add(series3);
            LineChartExpense.Title = "Real-time Server Load";
            LineChartExpense.ShowXCoordinates = false;
            LineChartExpense.ShowLegendTitle = false;
            LineChartExpense.LayoutPanel.Margin = new Margins(0, 0, 20, 0);

            LineChartExpense.XAxis.Title = "";
            LineChartExpense.XAxis.MinValue = 0;
            LineChartExpense.XAxis.MaxValue = 120;
            LineChartExpense.XAxis.Interval = 10;
            LineChartExpense.XAxis.Title = "Expenses";

            LineChartExpense.YAxis.MinValue = 0;
            LineChartExpense.YAxis.MaxValue = 100;
            LineChartExpense.YAxis.Interval = 10;
            LineChartExpense.YAxis.Title = "Income";

            List<Brush> brushes = new List<Brush>()
            {
                new SolidBrush(Color.FromArgb(206, 0, 0)),
                new SolidBrush(Color.FromArgb(90, 121, 165)),
                new SolidBrush(Color.FromArgb(0, 52, 102))
            };

            List<double> thicknesses = new List<double>() { 2 };

            PerSeriesStyle style = new PerSeriesStyle(brushes, brushes, thicknesses, null);
            LineChartExpense.Plot.SeriesStyle = style;
            LineChartExpense.Theme.PlotBackground = new SolidBrush(Color.White);    
            LineChartExpense.Theme.GridLineColor = Color.LightGray;
            LineChartExpense.Theme.GridLineStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            LineChartExpense.TitleMargin = new Margins(10);
            LineChartExpense.GridType = GridType.Horizontal;

            myTimer.Tick += new EventHandler(TimerEventProcessor);

            myTimer.Interval = 500;
            myTimer.Start();
        }

        private void TimerEventProcessor(Object myObject,
        EventArgs myEventArgs)
        {
            double val = random.NextDouble() * 10 + 10;
            series1.addValue(val);

            val = random.NextDouble() * 10 + 40;
            series2.addValue(val);

            val = random.NextDouble() * 10 + 60;
            series3.addValue(val);
            Console.WriteLine(val);

            if (series1.Size > 1)
            {
                double currVal = series1.GetValue(series1.Size - 1, 0);

                if (currVal > LineChartExpense.XAxis.MaxValue)
                {
                    double span = currVal - series1.GetValue(series1.Size - 2, 0);
                    LineChartExpense.XAxis.MinValue += span;
                    LineChartExpense.XAxis.MaxValue += span;

                }
                LineChartExpense.ChartPanel.InvalidateLayout();
            }

        }
    }
}