﻿using Npgsql;
using System;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class TransactionWindow : Form
    {
        private NpgsqlConnection cn = new NpgsqlConnection(Config.ConnectionString);
        // private NpgsqlConnection cn = new NpgsqlConnection("Server=localhost;port=5432;Database=casepointpgsql;User Id=postgres;Password=Pritam@123");
        readonly int userid;

        public TransactionWindow(int id)
        {

            this.userid = id;
            InitializeComponent();
            loadTransactionData("sender", "t.c_timestamp DESC", expense_grid, totalSpent);
            loadTransactionData("receiver", "t.c_timestamp DESC", recieved_grid, totalReceived);
        }

        // Function to load transactions based on sender/receiver filter
        public void loadTransactionData(string sender_receiver, string filter, DataGridView dgv, Label totalamt)
        {

            string send_rec = sender_receiver == "sender" ? "t.c_sender" : "t.c_receiver";
            string rev_send_rec = sender_receiver != "sender" ? "t.c_sender" : "t.c_receiver";
            int accNum = loadAccNum();

            string query = $"select t.c_tid as \"TransactionID\",concat(c.c_fname,' ',c.c_lname)  as \"Name\",t.c_note as \"Note\",t.c_amount as \"Amount ₹\",t.c_timestamp as \"Date and Time\" from t_transactions t join t_account ac on {rev_send_rec} = ac.c_account_num join t_customer c on ac.c_id = c.c_id where {send_rec} = @send_rec_Acc order by {filter}";
            string queryTotal = $"select sum(t.c_amount)  from t_transactions as t where {send_rec} = @id and t.c_timestamp::date = current_date";

            NpgsqlCommand cmd, cmdTotal;
            cmd = new NpgsqlCommand(query, cn);
            cmdTotal = new NpgsqlCommand(queryTotal, cn);
            DataTable dt = new DataTable();
            try
            {
                cn.Open();
                cmd.Parameters.AddWithValue("send_rec_Acc", accNum);
                cmdTotal.Parameters.AddWithValue("id", accNum);

                string reader;

                dt.Load(cmd.ExecuteReader());
                object totalAmtData = cmdTotal.ExecuteScalar();

                if (totalAmtData != null && totalAmtData != DBNull.Value) totalamt.Text = totalAmtData.ToString();
                else totalamt.Text = "0.00";
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        // Filter change handler for received transactions
        public void received_filter_changed(object sender, EventArgs args)
        {
            string filter = cmb_filter_received.SelectedItem?.ToString();

            switch (filter)
            {
                case "Name":
                    filter = "c.c_fname,t.c_timestamp";
                    break;
                case "Date":
                    filter = "t.c_timestamp DESC";
                    break;
                case "Expense Amt":
                    filter = "t.c_amount DESC";
                    break;
                default:
                    filter = "t.c_timestamp DESC";
                    break;
            }

            // Load data into received_grid based on the selected filter
            loadTransactionData("receiver", filter, recieved_grid, totalReceived);
        }

        // Filter change handler for expense transactions
        public void expense_filter_changed(object sender, EventArgs args)
        {
            string filter = cmb_filter_expense.SelectedItem?.ToString();

            switch (filter)
            {
                case "Name":
                    filter = "c.c_fname,t.c_timestamp";
                    break;
                case "Date":
                    filter = "t.c_timestamp DESC";
                    break;
                case "Expense Amt":
                    filter = "t.c_amount DESC";
                    break;
                default:
                    filter = "t.c_timestamp DESC";
                    break;
            }

            // Load data into expense_grid based on the selected filter
            loadTransactionData("sender", filter, expense_grid, totalSpent);
        }

        public void ExportReceivedData(Object sender, EventArgs args)
        {
            Thread thread = new Thread(() => ExportToCSV(recieved_grid, "Received Report"));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
        }

        private void ExportExpenseData(object sender, EventArgs args)
        {
            Thread thread = new Thread(() => ExportToCSV(expense_grid, "Expense Report"));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
        }

        private void ExportToCSV(DataGridView dataGridView, string fileName)
        {
            //if (InvokeRequired)
            //{
            //    Invoke(new Action(() => ExportToCSV(dataGridView, fileName))); // Ensure running on UI thread
            //    return;
            //}

            // Create and configure the SaveFileDialog
            
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV file (*.csv)|*.csv";
            sfd.FileName = $"{fileName}.csv";
            sfd.ShowHelp = true;
        

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StringBuilder csvContent = new StringBuilder();

                        // Write the header row (column names)
                        for (int i = 0; i < dataGridView.Columns.Count; i++)
                        {
                            csvContent.Append(dataGridView.Columns[i].HeaderText);
                            if (i < dataGridView.Columns.Count - 1)
                                csvContent.Append(",");
                        }
                        csvContent.AppendLine();

                        // Write data rows
                        foreach (DataGridViewRow row in dataGridView.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dataGridView.Columns.Count; i++)
                                {
                                    object cellValue = row.Cells[i].Value;
                                    string cellText = cellValue?.ToString() ?? "";

                                    // Handle values containing commas, quotes, or newlines
                                    if (cellText.Contains(",") || cellText.Contains("\"") || cellText.Contains("\n"))
                                    {
                                        // Escape quotes by doubling them and enclose in quotes
                                        cellText = "\"" + cellText.Replace("\"", "\"\"") + "\"";
                                    }

                                    csvContent.Append(cellText);

                                    if (i < dataGridView.Columns.Count - 1)
                                        csvContent.Append(",");
                                }
                                csvContent.AppendLine();
                            }
                        }

                        // Write the content to the CSV file
                        File.WriteAllText(sfd.FileName, csvContent.ToString(), Encoding.UTF8);

                        MessageBox.Show("Data exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            
            

        }



        public int loadAccNum()
        {
            NpgsqlCommand cmd = new NpgsqlCommand("select c_account_num from t_account where c_id = @id", cn);
            cmd.Parameters.AddWithValue("id", userid);
            cn.Open();
            int id = int.Parse(cmd.ExecuteScalar().ToString());
            cn.Close();
            return id;
        }


    }
}
