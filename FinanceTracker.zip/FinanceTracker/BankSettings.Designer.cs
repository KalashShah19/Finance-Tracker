﻿namespace Project
{
    partial class BankSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_account_number = new Label();
            lb_ifsc = new Label();
            lb_bank_name = new Label();
            tb_account_number = new Label();
            tb_ifsc_code = new TextBox();
            cb_bank_name = new ComboBox();
            bt_update = new Button();
            lb_monthly_limit = new Label();
            npd_monthly_limit = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)npd_monthly_limit).BeginInit();
            SuspendLayout();
            // 
            // lb_account_number
            // 
            lb_account_number.AutoSize = true;
            lb_account_number.Location = new Point(46, 30);
            lb_account_number.Name = "lb_account_number";
            lb_account_number.Size = new Size(99, 15);
            lb_account_number.TabIndex = 0;
            lb_account_number.Text = "Account Number";
            // 
            // lb_ifsc
            // 
            lb_ifsc.AutoSize = true;
            lb_ifsc.Location = new Point(46, 118);
            lb_ifsc.Name = "lb_ifsc";
            lb_ifsc.Size = new Size(61, 15);
            lb_ifsc.TabIndex = 1;
            lb_ifsc.Text = "IFSC Code";
            // 
            // lb_bank_name
            // 
            lb_bank_name.AutoSize = true;
            lb_bank_name.Location = new Point(46, 74);
            lb_bank_name.Name = "lb_bank_name";
            lb_bank_name.Size = new Size(68, 15);
            lb_bank_name.TabIndex = 2;
            lb_bank_name.Text = "Bank Name";
            // 
            // tb_account_number
            // 
            tb_account_number.Location = new Point(191, 27);
            tb_account_number.Name = "tb_account_number";
            tb_account_number.Size = new Size(100, 23);
            tb_account_number.TabIndex = 3;
            // 
            // tb_ifsc_code
            // 
            tb_ifsc_code.Location = new Point(191, 110);
            tb_ifsc_code.Name = "tb_ifsc_code";
            tb_ifsc_code.Size = new Size(100, 23);
            tb_ifsc_code.TabIndex = 4;
            // 
            // cb_bank_name
            // 
            cb_bank_name.FormattingEnabled = true;
            cb_bank_name.Location = new Point(181, 71);
            cb_bank_name.Name = "cb_bank_name";
            cb_bank_name.Size = new Size(121, 23);
            cb_bank_name.TabIndex = 5;
            cb_bank_name.Items.AddRange(new string[] { "Axis Bank", "Bank of Baroda", "ICICI", "State Bank of India" });
            // 
            // bt_update
            // 
            bt_update.Location = new Point(125, 194);
            bt_update.Name = "bt_update";
            bt_update.Size = new Size(75, 23);
            bt_update.TabIndex = 6;
            bt_update.Text = "Update";
            bt_update.UseVisualStyleBackColor = true;
            bt_update.Click += UpdateUserData;
            // 
            // lb_monthly_limit
            // 
            lb_monthly_limit.AutoSize = true;
            lb_monthly_limit.Location = new Point(46, 158);
            lb_monthly_limit.Name = "lb_monthly_limit";
            lb_monthly_limit.Size = new Size(82, 15);
            lb_monthly_limit.TabIndex = 7;
            lb_monthly_limit.Text = "Monthly Limit";
            // 
            // npd_monthly_limit
            // 
            npd_monthly_limit.Location = new Point(182, 156);
            npd_monthly_limit.Name = "npd_monthly_limit";
            npd_monthly_limit.Size = new Size(120, 23);
            npd_monthly_limit.TabIndex = 8;
            npd_monthly_limit.Minimum = 1000;
            npd_monthly_limit.Maximum = 50000;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(341, 240);
            Controls.Add(npd_monthly_limit);
            Controls.Add(lb_monthly_limit);
            Controls.Add(bt_update);
            Controls.Add(cb_bank_name);
            Controls.Add(tb_ifsc_code);
            Controls.Add(tb_account_number);
            Controls.Add(lb_bank_name);
            Controls.Add(lb_ifsc);
            Controls.Add(lb_account_number);
            Name = "Form3";
            Text = "Bank Settings";
            ((System.ComponentModel.ISupportInitialize)npd_monthly_limit).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lb_account_number;
        private Label lb_ifsc;
        private Label lb_bank_name;
        private Label tb_account_number;
        private TextBox tb_ifsc_code;
        private ComboBox cb_bank_name;
        private Button bt_update;
        private Label lb_monthly_limit;
        private NumericUpDown npd_monthly_limit;
    }
}