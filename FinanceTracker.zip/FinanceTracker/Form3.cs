﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_windos
{
    public partial class Form3 : Form
    {
         public static string MD5Hash(string text)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            return sb.ToString();
        }
        public string UserInput { get; private set; }
        string  UserPIN;
        int User_id;
        NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);

        public Form3(int id )
        {
            this.User_id = id;
            InitializeComponent();
            isPIN();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtPIN.Text == "")
            {
                msgForPIN.Text = "Please enter a PIN";
                msgForPIN.ForeColor = Color.Red;
            }
            else
            {
                UserInput = txtPIN.Text;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void txtPIN_TextChanged(object sender, EventArgs e)
        {
            if (txtPIN.Text == "")
            {
                msgForPIN.Text = "";
                msgForPIN.ForeColor = Color.Red;
            }
            else
            {
                if (txtPIN.Text.Length == 4)
                {
                    msgForPIN.Text = "";
                    msgForPIN.ForeColor = Color.Red;
                    if (UserPIN == MD5Hash(txtPIN.Text))
                    {
                        msgForPIN.Text = "";
                        msgForPIN.ForeColor = Color.Red;
                    }
                    else
                    {
                        msgForPIN.Text = "Enter the correct PIN";
                        msgForPIN.ForeColor = Color.Red;
                    }

                }
                else
                {
                    msgForPIN.Text = "Please enter a 4 digit PIN";
                    msgForPIN.TextAlign = ContentAlignment.MiddleCenter;
                    msgForPIN.ForeColor = Color.Red;
                }
            }
        }

        public string isPIN()
        {
            conn.Open();
            NpgsqlCommand cmd = new NpgsqlCommand("SELECT acc.c_balance, acc.c_account_num, cust.c_pin FROM t_account acc INNER JOIN t_customer cust ON acc.c_id = cust.c_id WHERE acc.c_id = @User_id", conn);

            cmd.Parameters.AddWithValue("@User_id", Dashboard.User_id);

            NpgsqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                UserPIN = reader["c_pin"].ToString();
                //button1.Text = UserPIN.ToString();
            }
            conn.Close();
            return UserPIN;
        }
    }
}
