﻿namespace WinFormsApp1
{
    partial class TransactionWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            recieved_grid = new DataGridView();
            export_t_daa = new Button();
            cmb_filter_received = new ComboBox();
            label1 = new Label();
            expense_grid = new DataGridView();
            button1 = new Button();
            cmb_filter_expense = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            totalSpent = new Label();
            label7 = new Label();
            totalReceived = new Label();
            ((System.ComponentModel.ISupportInitialize)recieved_grid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)expense_grid).BeginInit();
            SuspendLayout();
            // 
            // recieved_grid
            // 
            recieved_grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            recieved_grid.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.DarkSeaGreen;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            recieved_grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            recieved_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            recieved_grid.EnableHeadersVisualStyles = false;
            recieved_grid.Location = new Point(50, 57);
            recieved_grid.Name = "recieved_grid";
            recieved_grid.RowHeadersWidth = 51;
            recieved_grid.RowTemplate.Height = 28;
            recieved_grid.Size = new Size(693, 196);
            recieved_grid.TabIndex = 0;
            // 
            // export_t_daa
            // 
            export_t_daa.ImageAlign = ContentAlignment.MiddleLeft;
            export_t_daa.Location = new Point(641, 276);
            export_t_daa.Name = "export_t_daa";
            export_t_daa.Padding = new Padding(0, 0, 0, 2);
            export_t_daa.Size = new Size(102, 36);
            export_t_daa.TabIndex = 1;
            export_t_daa.Text = "Export";
            export_t_daa.TextImageRelation = TextImageRelation.ImageBeforeText;
            export_t_daa.UseVisualStyleBackColor = true;
            export_t_daa.Click += ExportReceivedData;
            // 
            // cmb_filter_received
            // 
            cmb_filter_received.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_filter_received.FormattingEnabled = true;
            cmb_filter_received.Items.AddRange(new object[] { "Name", "Date", "Amt" });
            cmb_filter_received.Location = new Point(580, 13);
            cmb_filter_received.Name = "cmb_filter_received";
            cmb_filter_received.Size = new Size(153, 28);
            cmb_filter_received.TabIndex = 2;
            cmb_filter_received.SelectedIndexChanged += received_filter_changed;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(517, 13);
            label1.Name = "label1";
            label1.Size = new Size(65, 28);
            label1.TabIndex = 3;
            label1.Text = "Filter :";
            // 
            // expense_grid
            // 
            expense_grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            expense_grid.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.PaleVioletRed;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            expense_grid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            expense_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            expense_grid.EnableHeadersVisualStyles = false;
            expense_grid.Location = new Point(50, 402);
            expense_grid.Name = "expense_grid";
            expense_grid.RowHeadersWidth = 51;
            expense_grid.RowTemplate.Height = 28;
            expense_grid.Size = new Size(693, 196);
            expense_grid.TabIndex = 0;
            // 
            // button1
            // 
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(641, 621);
            button1.Name = "button1";
            button1.Padding = new Padding(0, 0, 0, 2);
            button1.Size = new Size(102, 36);
            button1.TabIndex = 1;
            button1.Text = "Export";
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = true;
            button1.Click += ExportExpenseData;
            // 
            // cmb_filter_expense
            // 
            cmb_filter_expense.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_filter_expense.FormattingEnabled = true;
            cmb_filter_expense.Items.AddRange(new object[] { "Name", "Date", "Amt" });
            cmb_filter_expense.Location = new Point(588, 358);
            cmb_filter_expense.Name = "cmb_filter_expense";
            cmb_filter_expense.Size = new Size(145, 28);
            cmb_filter_expense.TabIndex = 2;
            cmb_filter_expense.SelectedIndexChanged += expense_filter_changed;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(517, 358);
            label2.Name = "label2";
            label2.Size = new Size(65, 28);
            label2.TabIndex = 3;
            label2.Text = "Filter :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 20.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Crimson;
            label3.Location = new Point(50, 358);
            label3.Name = "label3";
            label3.Size = new Size(91, 39);
            label3.TabIndex = 4;
            label3.Text = "Sent";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 20.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.ForestGreen;
            label4.Location = new Point(50, 18);
            label4.Name = "label4";
            label4.Size = new Size(168, 39);
            label4.TabIndex = 4;
            label4.Text = "Received";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Crimson;
            label5.Location = new Point(419, 625);
            label5.Name = "label5";
            label5.Size = new Size(68, 25);
            label5.TabIndex = 5;
            label5.Text = "Today";
            // 
            // totalSpent
            // 
            totalSpent.AutoSize = true;
            totalSpent.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            totalSpent.ForeColor = Color.Crimson;
            totalSpent.Location = new Point(532, 621);
            totalSpent.Name = "totalSpent";
            totalSpent.Size = new Size(103, 31);
            totalSpent.TabIndex = 5;
            totalSpent.Text = "500.00";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.ForestGreen;
            label7.Location = new Point(419, 287);
            label7.Name = "label7";
            label7.Size = new Size(68, 25);
            label7.TabIndex = 5;
            label7.Text = "Today";
            // 
            // totalReceived
            // 
            totalReceived.AutoSize = true;
            totalReceived.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            totalReceived.ForeColor = Color.ForestGreen;
            totalReceived.Location = new Point(532, 281);
            totalReceived.Name = "totalReceived";
            totalReceived.Size = new Size(103, 31);
            totalReceived.TabIndex = 5;
            totalReceived.Text = "500.00";
            // 
            // TransactionWindow
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(781, 699);
            Controls.Add(totalReceived);
            Controls.Add(label7);
            Controls.Add(totalSpent);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cmb_filter_expense);
            Controls.Add(cmb_filter_received);
            Controls.Add(button1);
            Controls.Add(export_t_daa);
            Controls.Add(expense_grid);
            Controls.Add(recieved_grid);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "TransactionWindow";
            Padding = new Padding(2);
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)recieved_grid).EndInit();
            ((System.ComponentModel.ISupportInitialize)expense_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView recieved_grid;
        private Button export_t_daa;
        private ComboBox cmb_filter_received;
        private Label label1;
        private DataGridView expense_grid;
        private Button button1;
        private ComboBox cmb_filter_expense;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label totalSpent;
        private Label label7;
        private Label totalReceived;
    }
}