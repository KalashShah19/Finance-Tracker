using Npgsql;
using Project;
using System.Text;
using System.Security.Cryptography;
using WinFormsApp1;

namespace login_windos
{
    public partial class Dashboard : Form
    {

        int selfAccNo;
        public static int User_id;
        int receiver_id;
        int sender_id;
        string UserPIN;

        decimal monthly_limit = 0;

        NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);

        public Dashboard(int id)
        {
            InitializeComponent();
            User_id = id; // Set User ID

            //MessageBox.Show($"User ID set to: {User_id}");
            if (conn != null)
            {
                // MessageBox.Show("done");
            }
            IsBalance();
            // getSenderID();


            // MessageBox.Show(User_id.ToString());
            getName();
        }

        private void btnBalance_Click(object sender, EventArgs e)
        {

        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static string MD5Hash(string text)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("X2"));
            }
            return sb.ToString();
        }


        private void btnTransfer_Click_1(object sender, EventArgs e)
        {
            if (validation() == true)
            {
                if (IsBalance() > 0 && IsBalance() >= double.Parse(txtboxAmount.Text))
                {
                    if (selfAccNo != int.Parse(txtboxAccountNumber.Text.ToString()))
                    {
                        if (!check_monthly_limit())
                        {
                            try
                            {
                                conn.Open();
                                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE t_account SET c_balance=c_balance + @amt WHERE c_account_num=@Reciever_Acc_no", conn);
                                NpgsqlCommand cmd1 = new NpgsqlCommand("UPDATE t_account SET c_balance=c_balance - @amt WHERE c_id = @User_id", conn);

                                NpgsqlCommand cmd2 = new NpgsqlCommand("INSERT INTO t_transactions( c_amount, c_sender, c_receiver, c_note) VALUES(@amt, @sender_id, @receiver_id,  @note)", conn);

                                cmd.Parameters.AddWithValue("@Reciever_Acc_no", long.Parse(txtboxAccountNumber.Text));
                                cmd.Parameters.AddWithValue("@amt", double.Parse(txtboxAmount.Text));


                                cmd1.Parameters.AddWithValue("@amt", double.Parse(txtboxAmount.Text));
                                cmd1.Parameters.AddWithValue("@User_id", long.Parse(User_id.ToString()));

                                cmd2.Parameters.AddWithValue("@amt", double.Parse(txtboxAmount.Text));
                                cmd2.Parameters.AddWithValue("@receiver_id", int.Parse(txtboxAccountNumber.Text));
                                cmd2.Parameters.AddWithValue("@sender_id", selfAccNo);
                                cmd2.Parameters.AddWithValue("@note", txtboxNote.Text);

                                conn.Close();

                                Form3 form3 = new Form3(User_id);

                                if (form3.ShowDialog() == DialogResult.OK)
                                {
                                    conn.Open();
                                    string userInput = form3.UserInput;
                                    string hash = MD5Hash(userInput);
                                    if (hash == UserPIN)
                                    {
                                        int row = cmd.ExecuteNonQuery();

                                        if (row > 0)
                                        {
                                            cmd1.ExecuteNonQuery();
                                            cmd2.ExecuteNonQuery();
                                            MessageBox.Show("Transaction Successfully");

                                            conn.Close();
                                            IsBalance();
                                            CleanData();
                                        }
                                        else
                                        {
                                            MessageBox.Show("Invalid Account No");
                                            CleanData();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please enter a correct PIN");
                                        conn.Close();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }


                        }
                        else
                        {
                            MessageBox.Show("Monthly Limit Exceeeded");
                            CleanData();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Balance Not Available");
                        //label4.Text = "Balance Not Available";
                        CleanData();
                    }
                }
                else
                {
                    MessageBox.Show("Do not Transfer self Account");
                }
            }
        }

        public void SelectSettings(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    {
                        Task.Run(new BankSettings(User_id).ShowDialog);
                        break;
                    }

                case 0:
                    {
                        Task.Run(new PasswordSettings(User_id).ShowDialog);
                        break;
                    }

                case 2:
                    {
                        Task.Run(new ProfileSettings(User_id).ShowDialog);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }
        }

        void getName()
        {

            conn.Open();
            NpgsqlCommand cmd = new NpgsqlCommand("SELECT c_fname FROM t_customer WHERE c_id = @User_id", conn);
            cmd.Parameters.AddWithValue("@User_id", User_id);
            NpgsqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblWelComeuser.Text = "Welcome " + reader["c_fname"].ToString();
                // MessageBox.Show(reader["c_fname"].ToString());

            }
            else
            {
                MessageBox.Show("error");
            }
            conn.Close();

        }

        double IsBalance()
        {
            //MessageBox.Show(User_id.ToString());
            double balance = 0;
            conn.Open();
            NpgsqlCommand cmd = new NpgsqlCommand("SELECT acc.c_balance, acc.c_account_num, cust.c_pin, cust.c_fname,acc.c_monthly_limit FROM t_account acc INNER JOIN t_customer cust ON acc.c_id = cust.c_id WHERE cust.c_id = @User_id", conn);
            cmd.Parameters.AddWithValue("@User_id", User_id);
            NpgsqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    btnBalance.Text = double.Parse(reader["c_balance"].ToString()).ToString();
                    balance = double.Parse(reader["c_balance"].ToString());
                    UserPIN = reader["c_pin"].ToString();
                    selfAccNo = int.Parse(reader["c_account_num"].ToString());
                    lblWelComeuser.Text += reader["c_fname"].ToString();
                }
            }
            else
            {
                MessageBox.Show("gbtdrxcxfcfx" + User_id);
                lblWelComeuser.Text = "No data available for the given user ID.";
                btnBalance.Text = "0"; // Optionally set to zero or a default value
            }

            conn.Close();
            return balance;
        }
        bool validation()
        {
            if (txtboxAccountNumber.Text.Trim() == "")
            {
                MessageBox.Show("Enter Reciever Account No");
                return false;
            }
            else if (txtboxAmount.Text.Trim() == "")
            {
                MessageBox.Show("Enter Amount");
                return false;
            }
            else if (txtboxNote.Text.Trim()=="")
            {
                MessageBox.Show("Enter Note.");
                return false;
            }
            else
            {
                return true;
            }
        }
        void CleanData()
        {
            txtboxAccountNumber.Text = "";
            txtboxAmount.Text = "";
            conn.Close();
            // btnBalance.Text = "";
            lblName.Text = "";
            lnbFullName.Text = "";
            txtboxNote.Text = "";
        }

        // public void getSenderID()
        // {
        //     conn.Open();

        //     NpgsqlCommand cmd2 = new NpgsqlCommand("SELECT acc.c_id FROM t_customer cust JOIN t_account acc ON cust.c_id = acc.c_id WHERE acc.c_id = @Sender_id", conn);

        //     cmd2.Parameters.AddWithValue("@Sender_id", User_id);

        //     NpgsqlDataReader reader2 = cmd2.ExecuteReader();
        //     if (reader2.Read())
        //     {
        //         sender_id = int.Parse(reader2["c_id"].ToString());
        //     }
        //     else
        //     {
        //         MessageBox.Show("ddgdgdgg");
        //     }
        //     conn.Close();
        // }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            conn.Close();
            try
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT cust.c_fname, cust.c_lname FROM t_customer cust JOIN t_account acc ON cust.c_id = acc.c_id WHERE c_account_num = @AccNo", conn);
                cmd.Parameters.AddWithValue("@AccNo", int.Parse(txtboxAccountNumber.Text));
                NpgsqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    lblFullName.Text = reader["c_fname"].ToString();
                }
            }
            catch
            {

            }
            finally { conn.Close(); }
        }
        private void txtboxAccountNumber_TextChanged(object sender, EventArgs e)
        {
            conn.Close();
            try
            {
                if (txtboxAccountNumber.Text == "")
                {
                    lblName.Text = "";
                    lnbFullName.Text = "";
                }
                else
                {
                    conn.Open();
                    NpgsqlCommand cmd = new NpgsqlCommand("SELECT cust.c_fname, cust.c_lname, acc.c_bank_name, acc.c_id FROM t_customer cust JOIN t_account acc ON cust.c_id = acc.c_id WHERE c_account_num = @AccNo", conn);

                    cmd.Parameters.AddWithValue("@AccNo", int.Parse(txtboxAccountNumber.Text));

                    NpgsqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        lblName.Text = reader["c_fname"].ToString();
                        lnbFullName.Text = reader["c_bank_name"].ToString();
                        receiver_id = int.Parse(reader["c_id"].ToString());
                        sender_id = int.Parse(reader["senderID"].ToString());
                    }
                    else
                    {
                        lblName.Text = "Not Found";
                        lnbFullName.Text = "Not Found";
                    }
                }
            }
            catch
            {

            }
            finally { conn.Close(); }
        }

        public bool check_monthly_limit()
        {
            decimal monthly_limit = 0;
            decimal totalTransactions = 0;
            bool flag = false;

            conn.Open();
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT c_monthly_limit FROM t_account WHERE c_id = @User_id", conn);
                cmd.Parameters.AddWithValue("@User_id", User_id);
                NpgsqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        monthly_limit = Convert.ToDecimal(reader["c_monthly_limit"]);
                    }
                }
                else
                {
                    MessageBox.Show("Monthly Limit not set");
                    return false;
                }

                reader.Close();

                NpgsqlCommand cmdTotal = new NpgsqlCommand(
                    "SELECT SUM(c_amount) FROM t_transactions " +
                    "WHERE c_sender = @User_id AND DATE_TRUNC('month', c_timestamp) = DATE_TRUNC('month', CURRENT_DATE)", conn);
                cmdTotal.Parameters.AddWithValue("@User_id", User_id);

                object result = cmdTotal.ExecuteScalar();
                totalTransactions = result != DBNull.Value ? Convert.ToDecimal(result) : 0;

                flag = totalTransactions >= monthly_limit;
            }
            finally
            {
                conn.Close();
            }

            return flag;
        }

        public void OpenHistory(object sender, EventArgs e)
        {
            Task.Run(new TransactionWindow(User_id).ShowDialog);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to log out?", "Confirm Logout", MessageBoxButtons.YesNo);

            if (confirmResult == DialogResult.Yes)
            {

                this.Hide();

                login loginForm = new login();
                loginForm.Show();


                User_id = 0;
                selfAccNo = 0;


            }
        }

        private void btnreports_Click(object sender, EventArgs e)
        {
            Reports report = new Reports();
            report.Show();
        }
    }
}

// kumarayush2104@gmail.com