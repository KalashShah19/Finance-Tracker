using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;//for mail
using System.Net.Mail;//for mail
using Npgsql;

namespace login_windos;


public partial class email_chek : Form
{
    private string email;
    private string generatedOTP;
    private int customerId;
    NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);

    public email_chek()
    {
        InitializeComponent();
    }

    public void email_chek_onchanged(object sender, EventArgs e)
    {

        string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

        bool email_match = Regex.IsMatch(txtemail.Text, emailPattern);

        string message = email_match ? "" : "Email is invalid";
        label3.ForeColor = System.Drawing.Color.Red;
        label3.Text = message;


    }

    public void submit_click(object sender, EventArgs e)
    {

        string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

        bool email_match = Regex.IsMatch(txtemail.Text, emailPattern);

        if (email_match)
        {
            email = txtemail.Text.ToString();
            // Query to check if a record exists
            string query = "SELECT c_id FROM t_customer WHERE c_email = @c_email";


            conn.Open();

            using (var cmd = new NpgsqlCommand(query, conn))
            {
                // Replace "@your_value" with the actual value to check
                cmd.Parameters.AddWithValue("@c_email", txtemail.Text);

                object result = cmd.ExecuteScalar();
                // Execute the query and get the count
                int recordCount = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();

                // Check if the record exists
                if (result != null)
                {
                    // If a record exists, result will contain the c_id
                    customerId = Convert.ToInt32(result);
                    //MessageBox.Show(customerId.ToString());

                    try
                    {
                        generatedOTP = GenerateOTP();
                        SendEmailwithOtp(email, generatedOTP);
                        MessageBox.Show("OTP has been sent to your email.");
                        otp_page op = new otp_page(email, generatedOTP,customerId);
                        op.Show();
                        this.Hide();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error sending email: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("Email does not exist!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }




        }
        else
        {
            MessageBox.Show("Please enter your email address.");
            return;
        }

    }

    private async void SendEmailwithOtp(string toEmail, string otp)
    {

        string fromEmail = "omniiyu2022@gmail.com"; // Replace with your email
        string fromPassword = "qlut heih fdih nzyk";
        // Replace with your email password

        // Read and update the email template
        string emailTemplatePath = Config.emailTemplatePath; // Path to your HTML template
        string emailBody = File.ReadAllText(emailTemplatePath);
        emailBody = emailBody.Replace("{{OTP}}", otp);


        MailMessage mailMessage = new MailMessage();
        mailMessage.From = new MailAddress(fromEmail);
        mailMessage.To.Add(toEmail);
        mailMessage.Subject = "Your OTP Code";
        mailMessage.Body = emailBody;
        mailMessage.IsBodyHtml = true;                    // Mark the body as HTML

        SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
        smtpClient.Credentials = new NetworkCredential(fromEmail, fromPassword);
        smtpClient.EnableSsl = true;

        smtpClient.Send(mailMessage);

    }

    private string GenerateOTP()
    {
        Random random = new Random();
        return random.Next(1000, 9999).ToString();
    }
}


