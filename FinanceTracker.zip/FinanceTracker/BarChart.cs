﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using MindFusion.Charting;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using MindFusion.Charting;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Drawing.Imaging;

namespace login_windos
{
    public partial class BarChart : Form
    {
        string connectionString = Config.ConnectionString;

        public BarChart()
        {
            InitializeComponent();
            LoadMonthlyExpensesAndConfigureBarChart();
        }

        public void LoadMonthlyExpensesAndConfigureBarChart()
        {
            // Retrieve the data from the database
            var (amounts, total, months) = GetMonthlyExpensesFromDatabase();

            int maxi = Convert.ToInt32(amounts.Max()) + 1000;

            // If data retrieval failed or is incomplete, exit the method
            if (amounts == null || total == null || amounts.Count == 0 || total.Count == 0 || amounts.Count != total.Count)
            {
                MessageBox.Show("Error: Unable to load data or mismatch in data counts.");
                return;
            }

            // foreach (var amount in amounts)
            // {
            //     MessageBox.Show(amount.ToString());
            // }

            // Initialize the bar chart series
            var series = new Series2D(months, amounts, total);
            series.Title = "Monthly Expenses";
            series.SupportedLabels = LabelKinds.ToolTip;

            // Configure the chart control (assuming BarChartExpense is your chart control)
            BarChartExpense.Series = new ObservableCollection<Series> { series };

            // Customize the axes
            BarChartExpense.XAxis.Title = "Months";
            BarChartExpense.YAxis.Title = "Expenses";
            BarChartExpense.XAxis.Interval = 1;
            BarChartExpense.YAxis.Interval = maxi / 10;
            BarChartExpense.XAxis.MaxValue = 12;
            BarChartExpense.XAxis.MinValue = 0;
            BarChartExpense.YAxis.MaxValue = maxi;
            BarChartExpense.YAxis.MinValue = 0;
        }

        private (IList<double> amounts, IList<string> total, IList<double> months) GetMonthlyExpensesFromDatabase()
        {
            IList<double> amounts = new List<double>();
            IList<string> total = new List<string>();
            IList<double> months = new List<double>();

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                    SELECT TO_CHAR(c_timestamp, 'YYYY-MM') AS MonthYear, SubString(TO_CHAR(c_timestamp, 'YYYY-MM'), 6) as months,
                    SUM(c_amount) AS TotalAmount 
                    FROM t_transactions 
                    GROUP BY TO_CHAR(c_timestamp, 'YYYY-MM') 
                    ORDER BY MonthYear;";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Ensure valid data before adding to lists
                                string? monthYear = reader["MonthYear"]?.ToString();
                                double month = Convert.ToDouble(reader["months"]);
                                if (double.TryParse(reader["TotalAmount"]?.ToString(), out double totalAmount))
                                {
                                    total.Add(reader["TotalAmount"].ToString()!);
                                    amounts.Add(totalAmount);
                                    months.Add(month);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Show the error message if data retrieval fails
                MessageBox.Show("Error retrieving data: " + ex.Message);
            }

            // Log the counts of both lists to ensure they are the same size
            if (amounts.Count != total.Count)
            {
                MessageBox.Show("Data mismatch: amounts and monthYears have different counts.");
            }


            // Return the data
            return (amounts, total, months);
        }


        public void btnDownloadBarChart_Click(object sender, EventArgs e)
        {
            // Step 1: Capture the chart as an image (same as before)
            using (Bitmap bmp = new Bitmap(BarChartExpense.Width, BarChartExpense.Height))
            {

                BarChartExpense.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, BarChartExpense.Width, BarChartExpense.Height));

                // Step 2: Use SaveFileDialog to let the user specify where to save the PDF
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PDF Files (.pdf)|.pdf";
                saveFileDialog.Title = "Save Chart as PDF";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;

                    try
                    {
                        // Step 3: Create the PDF document
                        Document pdfDoc = new Document(PageSize.A4);
                        PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
                        pdfDoc.Open();

                        iTextSharp.text.Font boldFont = iTextSharp.text.FontFactory.GetFont("Times-Roman", 20, iTextSharp.text.Font.BOLD);

                        // Step 4: Add the chart image to the PDF
                        using (MemoryStream stream = new MemoryStream())
                        {
                            // Save the chart image to a memory stream
                            bmp.Save(stream, ImageFormat.Png);
                            iTextSharp.text.Image chartImage = iTextSharp.text.Image.GetInstance(stream.ToArray());
                            chartImage.Alignment = Element.ALIGN_CENTER;
                            chartImage.ScaleToFit(500f, 400f); // Resize the image to fit in the PDF
                            pdfDoc.Add(chartImage); // Add the image to the PDF
                        }

                        PdfPTable pdfTable = new PdfPTable(2)
                        {
                            WidthPercentage = 100 // Set table width to 100%
                        };

                        // Step 5: Add a table to the PDF (for example, chart data)
                        // PdfPTable pdfTable = new PdfPTable(2); // Create a table with 2 columns
                        pdfTable.WidthPercentage = 100;
                        Paragraph header = new Paragraph(" : Monthly Expenses Report : ", boldFont)
                        {
                            Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 22),
                            SpacingBefore = 15f,
                            SpacingAfter = 5f,
                            Alignment = Element.ALIGN_CENTER

                        };

                        pdfDoc.Add(header);




                        pdfTable.SpacingBefore = 30f;
                        var headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 13);
                        headerFont.Color = BaseColor.BLUE;
                        PdfPCell cell = new PdfPCell(new Phrase("Custom Color Cell", headerFont));
                        // cell.BackgroundColor = new BaseColor(0, 0, 0);


                        iTextSharp.text.Font tableHeaderFont = iTextSharp.text.FontFactory.GetFont("Helvetica", 13, iTextSharp.text.Font.BOLD);
                        tableHeaderFont.Color = BaseColor.BLUE;
                        PdfPCell monthHeaderCell = new PdfPCell(new Phrase("Month", tableHeaderFont))
                        {
                            BackgroundColor = new BaseColor(0, 0, 0),
                            HorizontalAlignment = Element.ALIGN_CENTER,
                            Padding = 05,

                        };
                        PdfPCell expensesHeaderCell = new PdfPCell(new Phrase("Expenses", tableHeaderFont))
                        {
                            BackgroundColor = new BaseColor(0, 0, 0),
                            HorizontalAlignment = Element.ALIGN_CENTER,
                            Padding = 05
                        };
                        monthHeaderCell.Phrase.Font.Color = BaseColor.WHITE;

                        // Add the header cells to the table
                        pdfTable.AddCell(monthHeaderCell);
                        pdfTable.AddCell(expensesHeaderCell);


                        // pdfTable.AddCell(new PdfPCell(new Phrase("Month", headerFont)) { BackgroundColor = new BaseColor(0, 0, 0),  HorizontalAlignment = Element.ALIGN_CENTER,  Padding = 05  });
                        // pdfTable.AddCell(new PdfPCell(new Phrase("Expenses", headerFont)) {BackgroundColor = new BaseColor(0, 0, 0),  HorizontalAlignment = Element.ALIGN_CENTER,  Padding = 05 });
                        // pdfTable.AddCell(new PdfPCell(new Phrase("Expenses", headerFont)) { BackgroundColor = BaseColor.LIGHT_GRAY });

                        // Add table headers
                        // pdfTable.AddCell("Month");
                        // pdfTable.AddCell("Expenses");

                        // Assuming you have your data in amounts and monthYears lists
                        var (amounts, monthYears, _) = GetMonthlyExpensesFromDatabase();

                        // Add table rows with data
                        for (int i = 0; i < amounts.Count; i++)
                        {
                            PdfPCell monthCell = new PdfPCell(new Phrase(monthYears[i]))
                            {
                                HorizontalAlignment = Element.ALIGN_CENTER,
                                Padding = 5
                            };


                            PdfPCell amountCell = new PdfPCell(new Phrase(amounts[i].ToString("F2")))
                            {
                                HorizontalAlignment = Element.ALIGN_CENTER, // Center the text
                                Padding = 5
                            };
                            pdfTable.AddCell(monthCell);
                            pdfTable.AddCell(amountCell);
                            // pdfTable.AddCell(monthYears[i]);
                            // pdfTable.AddCell(amounts[i].ToString("F2")); // Format to 2 decimal places
                        }

                        // Add the table to the PDF
                        pdfDoc.Add(pdfTable);

                        // Step 6: Close the PDF document
                        pdfDoc.Close();

                        MessageBox.Show("PDF downloaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving the PDF: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

    }
}