using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using login_windos;
using System.Net;//for mail
using System.Net.Mail;
using demo;//for mail


public partial class otp_page : Form
{
    private string email;
    private string generatedOTP;
    private bool intime = true;
    private int timeLeft = 120;
    private int customerId;
    public otp_page(string email, string otp, int customerId)
    {
        InitializeComponent();
        this.email = email;
        this.generatedOTP = otp;
        this.customerId = customerId;

        label1.ForeColor = System.Drawing.Color.Red;
        timer1.Interval = 1000;
        timer1.Start();
    }


    public void timer_tick(object sender, EventArgs e)
    {
        label1.Text = "yash";
        if (timeLeft > 0)
        {
            // Update the label to show the remaining time in minutes and seconds
            label1.Text = $"{timeLeft / 60:D2}:{timeLeft % 60:D2}"; // Display as MM:SS

            timeLeft--; // Decrease the time left by 1 second
        }
        else
        {
            timer1.Stop();

            label1.Text = "Time's up!";
            MessageBox.Show("Time's up!");
            intime = false;
        }



    }

    public void submit_click(object sender, EventArgs e)
    {

        if (intime)
        {
            if (txtotp.Text == generatedOTP)
            {
                MessageBox.Show("OTP is correct", "Correct", MessageBoxButtons.OK, MessageBoxIcon.Information);
                forgetpass forgetpass = new forgetpass(email, customerId);
                forgetpass.Show();
                this.Close();

            }
            else
            {
                MessageBox.Show("OTP is incorrect", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        else
        {
            MessageBox.Show("Time's up!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }



    public void resendOtp_click(object sender, EventArgs e)
    {




        try
        {
            generatedOTP = GenerateOTP();
            SendEmailwithOtp(email, generatedOTP);
            MessageBox.Show("OTP has been sent to your email.");
            otp_page op = new otp_page(email, generatedOTP, customerId);
            op.Show();
            this.Hide();


        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error sending email: {ex.Message}");
        }





    }

    private async void SendEmailwithOtp(string toEmail, string otp)
    {

        string fromEmail = "omniiyu2022@gmail.com"; // Replace with your email
        string fromPassword = "qlut heih fdih nzyk";
        // Replace with your email password

        // Read and update the email template
        string emailTemplatePath = Config.emailTemplatePath; // Path to your HTML template
        string emailBody = File.ReadAllText(emailTemplatePath);
        emailBody = emailBody.Replace("{{OTP}}", otp);


        MailMessage mailMessage = new MailMessage();
        mailMessage.From = new MailAddress(fromEmail);
        mailMessage.To.Add(toEmail);
        mailMessage.Subject = "Your OTP Code";
        mailMessage.Body = emailBody;
        mailMessage.IsBodyHtml = true;                    // Mark the body as HTML

        SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
        smtpClient.Credentials = new NetworkCredential(fromEmail, fromPassword);
        smtpClient.EnableSsl = true;

        smtpClient.Send(mailMessage);

    }

    private string GenerateOTP()
    {
        Random random = new Random();
        return random.Next(1000, 9999).ToString();
    }




}

