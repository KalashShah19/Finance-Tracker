﻿using Npgsql;
using System.Text.RegularExpressions;

namespace Project
{
    public partial class BankSettings : Form
    {
        readonly int userid;
        readonly NpgsqlConnection connection;
        public BankSettings(int userid)
        {
            InitializeComponent();
            string connectionString = Config.ConnectionString;
            this.userid = userid;
            NpgsqlDataSource dataSource = NpgsqlDataSource.Create(connectionString);
            this.connection = dataSource.OpenConnection();
            GetUserData();
        }

        public void GetTheme()
        {
            NpgsqlCommand command = new("SELECT c_dark_theme FROM t_customer WHERE c_id = @id", connection);
            command.Parameters.AddWithValue("id", this.userid);
            NpgsqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                MessageBox.Show(reader.GetBoolean(0).ToString());
            }
        }

        public new bool Validate()
        {
            if (string.IsNullOrEmpty(tb_account_number.Text) || !Regex.IsMatch(tb_account_number.Text, @"^[0-9]{1,}$"))
            {
                MessageBox.Show("Please enter your valid account number");
                return false;
            }
            else if (string.IsNullOrEmpty(tb_ifsc_code.Text) || !Regex.IsMatch(tb_ifsc_code.Text, @"^[A-Z]{4}\d{7}$"))
            {
                MessageBox.Show("Please enter your IFSC code");
                return false;
            }
            else if (string.IsNullOrEmpty(cb_bank_name.Text))
            {
                MessageBox.Show("Please select your bank details");
                return false;
            }
            return true;
        }

        public void GetUserData()
        {
            NpgsqlCommand command = new("SELECT c_account_num, c_bank_name, c_ifsc_code, c_monthly_limit FROM t_account WHERE c_id = @id", connection);
            command.Parameters.AddWithValue("id", this.userid);
            NpgsqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                tb_account_number.Text = reader.GetInt64(0).ToString();
                cb_bank_name.Text = reader.GetString(1);
                tb_ifsc_code.Text = reader.GetString(2);
                npd_monthly_limit.Text = reader.GetInt64(3).ToString();
            }
            reader.Close();
        }

        public void UpdateUserData(object sender, EventArgs e)
        {
            if (!Validate()) return;
            NpgsqlCommand command = new("UPDATE t_account SET c_bank_name = @bank_name, c_ifsc_code = @ifsc_code, c_monthly_limit = @monthly_limit WHERE c_id = @id", connection);
            command.Parameters.AddWithValue("bank_name", cb_bank_name.Text);
            command.Parameters.AddWithValue("ifsc_code", tb_ifsc_code.Text);
            command.Parameters.AddWithValue("monthly_limit", long.Parse(npd_monthly_limit.Text));
            command.Parameters.AddWithValue("id", this.userid);
            command.ExecuteNonQuery();
            MessageBox.Show("Updated Successfully !");
            this.Close();
        }
    }
}
