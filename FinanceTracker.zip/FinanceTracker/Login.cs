using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Npgsql;
using System.Security.Cryptography;


namespace login_windos
{
    public partial class login : Form
    {
        private string email;
        private string password;
        NpgsqlConnection conn = new NpgsqlConnection(Config.ConnectionString);
        public login()
        {
            InitializeComponent();
        }

        public void email_chek_onchanged(object sender, EventArgs e)
        {

            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            bool email_match = Regex.IsMatch(txtemail.Text, emailPattern);

            string message = email_match ? "" : "Email is invalid";
            label3.ForeColor = System.Drawing.Color.Red;
            label3.Text = message;


        }

        public void password_chek_onchanged(object sender, EventArgs e)
        {
            string passwordPattern = @"^\d{4}$";

            string passwordMessage = "Input must be exactly 4 digits.";

            bool isValidPassword = Regex.IsMatch(txtpassword.Text, passwordPattern);

            string message = isValidPassword ? "" : passwordMessage;
            label4.ForeColor = System.Drawing.Color.Red;

            label4.Text = message;


        }

        public void login_button_click(object sender, EventArgs e)
        {

            string passwordPattern = @"^\d{4}$";
            bool isValidPassword = Regex.IsMatch(txtpassword.Text, passwordPattern);


            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            bool email_match = Regex.IsMatch(txtemail.Text, emailPattern);

            if (isValidPassword && email_match)
            {
                password = txtpassword.Text;
                MD5 md5 = MD5.Create();
                byte[] inputBytes = Encoding.ASCII.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                // lblemail.Text = sb.ToString().Trim();


                string query = "SELECT c_id FROM t_customer WHERE c_email = @c_email AND c_pin = @c_pin";

                conn.Open();

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    // Add the parameters for email and password
                    cmd.Parameters.AddWithValue("@c_email", txtemail.Text);
                    cmd.Parameters.AddWithValue("@c_pin", sb.ToString());

                    // Execute the query and get the result
                    object result = cmd.ExecuteScalar();

                    // Check if a record was found
                    if (result != null)
                    {
                        // If a record exists, result will contain the c_id
                        int customerId = Convert.ToInt32(result);
                       // MessageBox.Show($"Record exists! Customer ID: {customerId}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MessageBox.Show($"Welcome", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    /// dahbord code - connect -------------------------------------------------------------------------------------
                    /// 
                    this.Hide();
                    Dashboard dashboard = new Dashboard(customerId);
                        dashboard.Show();



                    }
                    else
                    {
                        // No record found
                        MessageBox.Show("Record does not exist!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

                conn.Close();
            }
            else
            {
                MessageBox.Show("Require all fields with correct information");
            }

        }

        public void checkbox_checked_change(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                txtpassword.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
            }

        }

        public void Forgetpassword_link_click(object sender, EventArgs e)
        {
            email_chek em = new email_chek();
            em.Show();
            // this.Hide();

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Tracker tracker = new Tracker();
            tracker.Show();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}
