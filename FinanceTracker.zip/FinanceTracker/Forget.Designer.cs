namespace demo
{
    partial class forgetpass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnsubmit = new Button();
            label1 = new Label();
            label4 = new Label();
            label3 = new Label();
            lblnewpassword = new Label();
            lblpassword = new Label();
            txtnewpassword = new TextBox();
            txtpassword = new TextBox();
            check_password = new CheckBox();
            check_new_password = new CheckBox();
            SuspendLayout();
            // 
            // btnsubmit
            // 
            btnsubmit.Location = new Point(275, 270);
            btnsubmit.Name = "btnsubmit";
            btnsubmit.Size = new Size(248, 42);
            btnsubmit.TabIndex = 25;
            btnsubmit.Text = "Submit";
            btnsubmit.UseVisualStyleBackColor = true;
            btnsubmit.Click += submit_click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 15F);
            label1.Location = new Point(308, 52);
            label1.Name = "label1";
            label1.Size = new Size(240, 43);
            label1.TabIndex = 24;
            label1.Text = "Reset Pin Number";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(275, 220);
            label4.Name = "label4";
            label4.Size = new Size(21, 20);
            label4.TabIndex = 23;
            label4.Text = "--";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(275, 141);
            label3.Name = "label3";
            label3.Size = new Size(21, 20);
            label3.TabIndex = 22;
            label3.Text = "--";
            // 
            // lblnewpassword
            // 
            lblnewpassword.AutoSize = true;
            lblnewpassword.Location = new Point(140, 193);
            lblnewpassword.Name = "lblnewpassword";
            lblnewpassword.Size = new Size(104, 20);
            lblnewpassword.TabIndex = 21;
            lblnewpassword.Text = "New Pin Number";
            // 
            // lblpassword
            // 
            lblpassword.AutoSize = true;
            lblpassword.Location = new Point(170, 114);
            lblpassword.Name = "lblpassword";
            lblpassword.Size = new Size(70, 20);
            lblpassword.TabIndex = 20;
            lblpassword.Text = "Pin Number";
            // 
            // txtnewpassword
            // 
            txtnewpassword.Location = new Point(275, 190);
            txtnewpassword.Name = "txtnewpassword";
            txtnewpassword.Size = new Size(248, 27);
            txtnewpassword.TabIndex = 19;
            txtnewpassword.PasswordChar = '*';
            txtnewpassword.TextChanged+=password_chek_new_onchanged;
            // 
            // txtpassword
            // 
            txtpassword.Location = new Point(275, 111);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(248, 27);
            txtpassword.TabIndex = 18;
            txtpassword.PasswordChar = '*';
            txtpassword.TextChanged+=password_chek_onchanged;
            // 
            // check_password
            // 
            check_password.AutoSize = true;
            check_password.Location = new Point(529, 114);
            check_password.Name = "check_password";
            check_password.Size = new Size(65, 24);
            check_password.TabIndex = 26;
            check_password.Text = "show";
            check_password.UseVisualStyleBackColor = true;
            check_password.CheckedChanged+=checkbox_checked_change;
            // 
            // check_new_password
            // 
            check_new_password.AutoSize = true;
            check_new_password.Location = new Point(529, 193);
            check_new_password.Name = "check_new_password";
            check_new_password.Size = new Size(65, 24);
            check_new_password.TabIndex = 27;
            check_new_password.Text = "show";
            check_new_password.UseVisualStyleBackColor = true;
            check_new_password.CheckedChanged += checkbox_checked_new_change;
            // 
            // forgetpass
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(check_new_password);
            Controls.Add(check_password);
            Controls.Add(btnsubmit);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblnewpassword);
            Controls.Add(lblpassword);
            Controls.Add(txtnewpassword);
            Controls.Add(txtpassword);
            Name = "forgetpass";
            Text = "forgetpass";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel linkLabel1;
        private Button btnsubmit;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label lblnewpassword;
        private Label lblpassword;
        private TextBox txtnewpassword;
        private TextBox txtpassword;
        private CheckBox check_password;
        private CheckBox check_new_password;
    }
}