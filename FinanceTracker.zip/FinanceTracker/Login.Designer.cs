namespace login_windos
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            linkLabel1 = new LinkLabel();
            btnsubmit = new Button();
            label1 = new Label();
            label4 = new Label();
            label3 = new Label();
            lblpassword = new Label();
            lblemail = new Label();
            txtpassword = new TextBox();
            txtemail = new TextBox();
            checkBox1 = new CheckBox();
            linkLabel2 = new LinkLabel();
            SuspendLayout();
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(330, 300);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(134, 20);
            linkLabel1.TabIndex = 17;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Forget Pin Number";
            linkLabel1.Click += Forgetpassword_link_click;
            // 
            // btnsubmit
            // 
            btnsubmit.Location = new Point(260, 249);
            btnsubmit.Name = "btnsubmit";
            btnsubmit.Size = new Size(248, 42);
            btnsubmit.TabIndex = 16;
            btnsubmit.Text = "Submit";
            btnsubmit.UseVisualStyleBackColor = true;
            btnsubmit.Click += login_button_click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(342, 44);
            label1.Name = "label1";
            label1.Size = new Size(87, 43);
            label1.TabIndex = 15;
            label1.Text = "Login";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(260, 199);
            label4.Name = "label4";
            label4.Size = new Size(21, 20);
            label4.TabIndex = 14;
            //label4.Text = "--";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(260, 131);
            label3.Name = "label3";
            label3.Size = new Size(21, 20);
            label3.TabIndex = 13;
            //label3.Text = "--";
            // 
            // lblpassword
            // 
            lblpassword.AutoSize = true;
            lblpassword.Location = new Point(140, 176);
            lblpassword.Name = "lblpassword";
            lblpassword.Size = new Size(87, 20);
            lblpassword.TabIndex = 12;
            lblpassword.Text = "Pin Number";
            // 
            // lblemail
            // 
            lblemail.AutoSize = true;
            lblemail.Location = new Point(183, 108);
            lblemail.Name = "lblemail";
            lblemail.Size = new Size(46, 20);
            lblemail.TabIndex = 11;
            lblemail.Text = "Email";
            // 
            // txtpassword
            // 
            txtpassword.Location = new Point(260, 169);
            txtpassword.Name = "txtpassword";
            txtpassword.PasswordChar = '*';
            txtpassword.Size = new Size(248, 27);
            txtpassword.TabIndex = 10;
            txtpassword.TextChanged += password_chek_onchanged;
            // 
            // txtemail
            // 
            txtemail.Location = new Point(260, 101);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(248, 27);
            txtemail.TabIndex = 9;
            txtemail.TextChanged += email_chek_onchanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(514, 172);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(65, 24);
            checkBox1.TabIndex = 18;
            checkBox1.Text = "show";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkbox_checked_change;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Location = new Point(295, 336);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(187, 20);
            linkLabel2.TabIndex = 19;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Not Registered? Click Here";
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(linkLabel2);
            Controls.Add(checkBox1);
            Controls.Add(linkLabel1);
            Controls.Add(btnsubmit);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lblpassword);
            Controls.Add(lblemail);
            Controls.Add(txtpassword);
            Controls.Add(txtemail);
            Name = "login";
            Text = "login";
            Load += login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel linkLabel1;
        private Button btnsubmit;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label lblpassword;
        private Label lblemail;
        private TextBox txtpassword;
        private TextBox txtemail;
        private CheckBox checkBox1;
        private LinkLabel linkLabel2;
    }
}