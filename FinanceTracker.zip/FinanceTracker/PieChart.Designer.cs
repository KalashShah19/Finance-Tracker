﻿namespace login_windos
{
    partial class PieChart : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PieChartExpense = new MindFusion.Charting.WinForms.PieChart();
            btnDownload = new Button();
            lblTitle = new Label();
            SuspendLayout();
            // 
            // PieChartExpense
            // 
            PieChartExpense.ChartPadding = 50;
            PieChartExpense.DetachOffset = 0F;
            PieChartExpense.LegendTitle = "Legend";
            PieChartExpense.Location = new Point(189, 42);
            PieChartExpense.Name = "PieChartExpense";
            PieChartExpense.Padding = new Padding(5);
            PieChartExpense.ShowLegend = true;
            PieChartExpense.Size = new Size(496, 358);
            PieChartExpense.StartAngle = 0F;
            PieChartExpense.SubtitleFontName = null;
            PieChartExpense.SubtitleFontSize = null;
            PieChartExpense.SubtitleFontStyle = null;
            PieChartExpense.TabIndex = 0;
            PieChartExpense.Text = "pieChart1";
            PieChartExpense.Theme.UniformSeriesFill = new MindFusion.Drawing.SolidBrush("#FF90EE90");
            PieChartExpense.Theme.UniformSeriesStroke = new MindFusion.Drawing.SolidBrush("#FF000000");
            PieChartExpense.Theme.UniformSeriesStrokeThickness = 2D;
            PieChartExpense.TitleFontName = null;
            PieChartExpense.TitleFontSize = null;
            PieChartExpense.TitleFontStyle = null;
            // 
            // btnDownload
            // 
            btnDownload.Location = new Point(367, 415);
            btnDownload.Name = "btnDownload";
            btnDownload.Size = new Size(142, 23);
            btnDownload.TabIndex = 4;
            btnDownload.Text = "Download Report";
            btnDownload.UseVisualStyleBackColor = true;
            btnDownload.Click += btnDownloadPieChart_Click;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(343, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(166, 25);
            lblTitle.TabIndex = 6;
            lblTitle.Text = "Expense Pie Chart";
            // 
            // PieChart
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTitle);
            Controls.Add(btnDownload);
            Controls.Add(PieChartExpense);
            Name = "PieChart";
            Text = "PieChart";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MindFusion.Charting.WinForms.PieChart PieChartExpense;
        private Button btnDownload;
        private Label lblTitle;
    }
}